# Theo Picture

A premium photography & videography portfolio app for a professional brand based in Quebec, Canada.

## Features

- **Home Screen**: Full-screen hero with animated brand introduction, services overview, featured work preview, client testimonials, and social links
- **Portfolio**: Grid gallery with Photos/Videos/Drone categories, tap-to-fullscreen image viewer
- **Services & Pricing**: Detailed pricing cards for Urban, Landscape, Drone, Architecture, and Custom projects with "Book" CTAs
- **About**: Personal bio, stats, equipment list, and social links
- **Contact**: Contact info with Instagram (@theo_totk), TikTok, email, phone, and message form
- **Booking Form**: Complete booking flow with email integration

## Booking Flow

The booking form sends photography requests directly to Theodore.beaupre@icloud.com:

**Form Fields:**
- Full name (required)
- Email (required)
- Service type (required): Urban/Landscape/Drone/Architecture/Custom
- Preferred date
- Location
- Budget (CAD)
- Project notes
- Preferred contact method: Email/Instagram/TikTok
- Social handle (optional, shown when Instagram/TikTok selected)

**Email Template:**
- Subject: "Théo Picture — New Photography Request"
- Body: Clean formatted template with all submitted fields

**After Submit:**
- Confirmation screen with success message
- Quick action buttons: Open Mail, DM Instagram (@theo_totk), DM TikTok (@theo_totk)
- Done button to close

## Design

- Dark mode first with elegant gold accents
- Apple-inspired clean, minimal aesthetic
- Smooth animations using react-native-reanimated
- iOS-style bottom tab navigation (5 tabs)
- Custom Instagram and TikTok icons

## Brand Colors

- Black: `#0A0A0A`
- Charcoal: `#1A1A1A`
- Gold: `#C9A962`
- Off-white: `#FAFAFA`

## Services & Pricing (CAD)

- Urban & City Photography: From $60
- Landscape & Nature: From $70
- Drone Photography: From $90
- Architecture & Buildings: From $75
- Custom Project: Quote on request

## Social Media

- Instagram: @theo_totk
- TikTok: @theo_totk

## Tech Stack

- Expo SDK 53
- React Native 0.76.7
- NativeWind (TailwindCSS)
- React Native Reanimated
- Expo Router (file-based routing)
- Expo Haptics (tactile feedback)

## Haptic Feedback

The app uses comprehensive haptic feedback for a premium tactile experience:

- **Tab Navigation**: Light haptic on tab switches
- **Buttons & CTAs**: Medium haptic for primary actions (Book, Submit)
- **Service Selection**: Selection haptic for picker interactions
- **Form Validation**: Error haptic for validation failures
- **Success States**: Success haptic for completed submissions
- **Social Links**: Light haptic for external link taps

Haptics are centralized in `src/lib/haptics.ts` for easy maintenance.

## Language System (Bilingual FR/EN)

The app supports both French and English with:

- **Default Language**: French (Français)
- **Language Detection**: Automatically detects device language on first launch
- **Persistence**: Language choice is saved via AsyncStorage
- **Instant Switching**: Changes apply immediately without app restart

### How to Switch Languages

1. Tap the **Settings** icon (gear) in the top-right of the Home screen
2. Select your preferred language (Français or English)
3. The app instantly updates all text

### Technical Implementation

- **Translations**: `src/lib/translations.ts` - Contains all translation strings
- **Context**: `src/lib/language-context.tsx` - React Context for language state
- **Hook**: `useLanguage()` - Returns `{ language, setLanguage, t }`
- **Usage**: `t('key.path')` returns the translated string

### Translated Screens

All screens are fully translated:
- Home (Accueil)
- Portfolio
- Services & Pricing (Services et tarifs)
- Booking (Réservation)
- About (À propos)
- Contact
- Settings (Paramètres)

### Drone Photography Notice

Drone photography is currently unavailable while the drone is being repaired. This is reflected:
- On the Services page: "Indisponible" badge and "Bientôt disponible" button
- On the Booking form: Option is greyed out with "(Indisponible)"
- On the Portfolio page: Notice banner when viewing Drone category
