import React from 'react';
import { View, Text, Pressable, Linking, ScrollView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { X, Check, Globe, Mail, ArrowUpRight } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import { useLanguage } from '@/lib/language-context';
import { hapticLight, hapticSelection } from '@/lib/haptics';
import type { Language } from '@/lib/translations';

// Custom Instagram icon component
function InstagramIcon({ size = 20, color = '#FAFAFA' }: { size?: number; color?: string }) {
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <View
        style={{
          width: size * 0.85,
          height: size * 0.85,
          borderRadius: size * 0.22,
          borderWidth: 1.5,
          borderColor: color,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <View
          style={{
            width: size * 0.35,
            height: size * 0.35,
            borderRadius: size * 0.175,
            borderWidth: 1.5,
            borderColor: color,
          }}
        />
        <View
          style={{
            position: 'absolute',
            top: size * 0.12,
            right: size * 0.12,
            width: size * 0.12,
            height: size * 0.12,
            borderRadius: size * 0.06,
            backgroundColor: color,
          }}
        />
      </View>
    </View>
  );
}

// Custom TikTok icon component
function TikTokIcon({ size = 20, color = '#FAFAFA' }: { size?: number; color?: string }) {
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ fontSize: size * 0.7, color, fontWeight: '700' }}>♪</Text>
    </View>
  );
}

const LANGUAGES: { id: Language; flag: string; name: { fr: string; en: string }; nativeName: string }[] = [
  { id: 'fr', flag: '🇫🇷', name: { fr: 'Français', en: 'French' }, nativeName: 'Français' },
  { id: 'en', flag: '🇬🇧', name: { fr: 'Anglais', en: 'English' }, nativeName: 'English' },
];

export default function SettingsScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { language, setLanguage, t } = useLanguage();

  const handleClose = () => {
    hapticLight();
    router.back();
  };

  const handleLanguageSelect = (lang: Language) => {
    if (lang !== language) {
      hapticSelection();
      setLanguage(lang);
    }
  };

  const openInstagram = () => {
    hapticLight();
    Linking.openURL('https://instagram.com/theo_totk');
  };

  const openTikTok = () => {
    hapticLight();
    Linking.openURL('https://tiktok.com/@theo_totk');
  };

  const openEmail = () => {
    hapticLight();
    Linking.openURL('mailto:Theodore.beaupre@icloud.com');
  };

  return (
    <View className="flex-1 bg-brand-black">
      {/* Header */}
      <View
        className="px-6 pb-4 flex-row items-center justify-between border-b border-brand-charcoal"
        style={{ paddingTop: insets.top + 12 }}
      >
        <Text className="text-brand-white text-xl font-light">
          {t('settings.title')}
        </Text>
        <Pressable
          onPress={handleClose}
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
          className="w-10 h-10 rounded-full bg-brand-charcoal items-center justify-center active:opacity-70"
          accessibilityLabel={t('common.done')}
          accessibilityRole="button"
        >
          <X size={20} color="#8A8A8A" />
        </Pressable>
      </View>

      <ScrollView
        className="flex-1"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: insets.bottom + 40 }}
      >
        <View className="px-6 pt-8">
          {/* Language Section */}
          <Animated.View entering={FadeInDown.duration(400)}>
            <View className="flex-row items-center mb-4">
              <Globe size={18} color="#C9A962" />
              <Text className="text-brand-gold text-xs tracking-[3px] uppercase ml-2">
                {t('settings.language')}
              </Text>
            </View>

            <View className="bg-brand-charcoal rounded-2xl overflow-hidden">
              {LANGUAGES.map((lang, index) => {
                const isSelected = language === lang.id;
                const isLast = index === LANGUAGES.length - 1;

                return (
                  <Animated.View
                    key={lang.id}
                    entering={FadeIn.duration(300).delay(index * 100)}
                  >
                    <Pressable
                      onPress={() => handleLanguageSelect(lang.id)}
                      hitSlop={{ top: 5, bottom: 5, left: 5, right: 5 }}
                      className={`flex-row items-center justify-between px-5 py-4 active:opacity-80 ${
                        !isLast ? 'border-b border-brand-gray/30' : ''
                      }`}
                      accessibilityLabel={`${lang.nativeName} ${isSelected ? '- Selected' : ''}`}
                      accessibilityRole="radio"
                      accessibilityState={{ checked: isSelected }}
                    >
                      <View className="flex-row items-center">
                        <Text className="text-2xl mr-4">{lang.flag}</Text>
                        <View>
                          <Text className={`text-base font-medium ${isSelected ? 'text-brand-gold' : 'text-brand-white'}`}>
                            {lang.nativeName}
                          </Text>
                          <Text className="text-brand-muted text-sm mt-0.5">
                            {lang.name[language]}
                          </Text>
                        </View>
                      </View>
                      {isSelected && (
                        <View className="w-6 h-6 rounded-full bg-brand-gold items-center justify-center">
                          <Check size={14} color="#0A0A0A" strokeWidth={3} />
                        </View>
                      )}
                    </Pressable>
                  </Animated.View>
                );
              })}
            </View>
          </Animated.View>

          {/* Info */}
          <Animated.View
            entering={FadeIn.duration(400).delay(300)}
            className="mt-4"
          >
            <Text className="text-brand-gray text-xs text-center leading-5">
              {language === 'fr'
                ? 'La langue sera changée instantanément.\nVotre choix est sauvegardé automatiquement.'
                : 'Language will be changed instantly.\nYour choice is saved automatically.'}
            </Text>
          </Animated.View>

          {/* Social Links Section */}
          <Animated.View entering={FadeInDown.duration(400).delay(200)} className="mt-10">
            <Text className="text-brand-gold text-xs tracking-[3px] uppercase mb-4">
              {language === 'fr' ? 'Réseaux sociaux' : 'Social Media'}
            </Text>

            {/* Instagram */}
            <Pressable
              onPress={openInstagram}
              className="bg-brand-charcoal rounded-2xl p-4 mb-3 flex-row items-center justify-between active:opacity-80"
            >
              <View className="flex-row items-center">
                <View className="w-10 h-10 rounded-xl bg-brand-gray items-center justify-center mr-3">
                  <InstagramIcon size={20} color="#C9A962" />
                </View>
                <View>
                  <Text className="text-brand-white text-base font-medium">Instagram</Text>
                  <Text className="text-brand-muted text-sm">@theo_totk</Text>
                </View>
              </View>
              <ArrowUpRight size={18} color="#8A8A8A" />
            </Pressable>

            {/* TikTok */}
            <Pressable
              onPress={openTikTok}
              className="bg-brand-charcoal rounded-2xl p-4 flex-row items-center justify-between active:opacity-80"
            >
              <View className="flex-row items-center">
                <View className="w-10 h-10 rounded-xl bg-brand-gray items-center justify-center mr-3">
                  <TikTokIcon size={20} color="#C9A962" />
                </View>
                <View>
                  <Text className="text-brand-white text-base font-medium">TikTok</Text>
                  <Text className="text-brand-muted text-sm">@theo_totk</Text>
                </View>
              </View>
              <ArrowUpRight size={18} color="#8A8A8A" />
            </Pressable>
          </Animated.View>

          {/* Contact Section */}
          <Animated.View entering={FadeInDown.duration(400).delay(300)} className="mt-10">
            <Text className="text-brand-gold text-xs tracking-[3px] uppercase mb-4">
              {language === 'fr' ? 'Contact' : 'Contact'}
            </Text>

            <Pressable
              onPress={openEmail}
              className="bg-brand-charcoal rounded-2xl p-4 flex-row items-center justify-between active:opacity-80"
            >
              <View className="flex-row items-center">
                <View className="w-10 h-10 rounded-xl bg-brand-gray items-center justify-center mr-3">
                  <Mail size={20} color="#C9A962" />
                </View>
                <View>
                  <Text className="text-brand-white text-base font-medium">
                    {language === 'fr' ? 'Courriel' : 'Email'}
                  </Text>
                  <Text className="text-brand-muted text-sm">Theodore.beaupre@icloud.com</Text>
                </View>
              </View>
              <ArrowUpRight size={18} color="#8A8A8A" />
            </Pressable>
          </Animated.View>

          {/* Footer */}
          <View className="mt-12 items-center">
            <Text className="text-brand-gray text-xs">
              {t('common.copyright')}
            </Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}
