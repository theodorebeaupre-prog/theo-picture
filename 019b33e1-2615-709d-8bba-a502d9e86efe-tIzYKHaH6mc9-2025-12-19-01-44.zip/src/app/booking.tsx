import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TextInput,
  Pressable,
  Linking,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useLocalSearchParams, useRouter } from 'expo-router';
import {
  X,
  Send,
  Check,
  Calendar,
  MapPin,
  DollarSign,
  ChevronDown,
  Mail,
  AtSign,
} from 'lucide-react-native';
import Animated, { FadeInDown, FadeIn, FadeOut } from 'react-native-reanimated';
import { hapticLight, hapticSuccess, hapticSelection, hapticError, hapticMedium } from '@/lib/haptics';
import { useLanguage } from '@/lib/language-context';

const DESTINATION_EMAIL = 'Theodore.beaupre@icloud.com';

// Custom Instagram icon component
function InstagramIcon({ size = 20, color = '#FAFAFA' }: { size?: number; color?: string }) {
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <View
        style={{
          width: size * 0.85,
          height: size * 0.85,
          borderRadius: size * 0.22,
          borderWidth: 1.5,
          borderColor: color,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <View
          style={{
            width: size * 0.35,
            height: size * 0.35,
            borderRadius: size * 0.175,
            borderWidth: 1.5,
            borderColor: color,
          }}
        />
        <View
          style={{
            position: 'absolute',
            top: size * 0.12,
            right: size * 0.12,
            width: size * 0.12,
            height: size * 0.12,
            borderRadius: size * 0.06,
            backgroundColor: color,
          }}
        />
      </View>
    </View>
  );
}

// Custom TikTok icon component
function TikTokIcon({ size = 20, color = '#FAFAFA' }: { size?: number; color?: string }) {
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ fontSize: size * 0.7, color, fontWeight: '700' }}>♪</Text>
    </View>
  );
}

export default function BookingScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const params = useLocalSearchParams<{ serviceId?: string; serviceTitle?: string }>();
  const { t, language } = useLanguage();

  const SERVICE_OPTIONS = [
    { id: 'urban', labelKey: 'services.urban.title' },
    { id: 'landscape', labelKey: 'services.landscape.title' },
    { id: 'drone', labelKey: 'services.drone.title', unavailable: true },
    { id: 'architecture', labelKey: 'services.architecture.title' },
    { id: 'custom', labelKey: 'services.custom.title' },
  ];

  const CONTACT_METHOD_OPTIONS = [
    { id: 'email', label: language === 'fr' ? 'Courriel' : 'Email' },
    { id: 'instagram', label: 'Instagram' },
    { id: 'tiktok', label: 'TikTok' },
  ];

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [selectedService, setSelectedService] = useState(params.serviceId || '');
  const [date, setDate] = useState('');
  const [location, setLocation] = useState('');
  const [notes, setNotes] = useState('');
  const [budget, setBudget] = useState('');
  const [preferredContact, setPreferredContact] = useState('email');
  const [socialHandle, setSocialHandle] = useState('');
  const [showServicePicker, setShowServicePicker] = useState(false);
  const [showContactPicker, setShowContactPicker] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const getServiceLabel = (serviceId: string) => {
    const service = SERVICE_OPTIONS.find((s) => s.id === serviceId);
    if (!service) return t('booking.selectService');
    const label = t(service.labelKey);
    return service.unavailable
      ? `${label} (${t('services.unavailable')})`
      : label;
  };

  const selectedServiceLabel = getServiceLabel(selectedService);

  const selectedContactLabel =
    CONTACT_METHOD_OPTIONS.find((c) => c.id === preferredContact)?.label ||
    (language === 'fr' ? 'Courriel' : 'Email');

  const buildEmailBody = () => {
    const serviceLabel = selectedService
      ? t(SERVICE_OPTIONS.find((s) => s.id === selectedService)?.labelKey || '')
      : (language === 'fr' ? 'Non spécifié' : 'Not specified');
    const contactLabel = selectedContactLabel;

    const lines = [
      '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━',
      language === 'fr'
        ? 'THÉO PICTURE — NOUVELLE DEMANDE DE PHOTOGRAPHIE'
        : 'THÉO PICTURE — NEW PHOTOGRAPHY REQUEST',
      '━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━',
      '',
      language === 'fr' ? '▸ INFORMATIONS CLIENT' : '▸ CLIENT INFORMATION',
      `  ${language === 'fr' ? 'Nom' : 'Name'}: ${name}`,
      `  ${language === 'fr' ? 'Courriel' : 'Email'}: ${email}`,
      '',
      language === 'fr' ? '▸ DÉTAILS DU PROJET' : '▸ PROJECT DETAILS',
      `  Service: ${serviceLabel}`,
      `  Date: ${date || (language === 'fr' ? 'Non spécifié' : 'Not specified')}`,
      `  ${language === 'fr' ? 'Lieu' : 'Location'}: ${location || (language === 'fr' ? 'Non spécifié' : 'Not specified')}`,
      `  Budget: ${budget ? `$${budget} CAD` : (language === 'fr' ? 'Non spécifié' : 'Not specified')}`,
      '',
      language === 'fr' ? '▸ NOTES DU PROJET' : '▸ PROJECT NOTES',
      `  ${notes || (language === 'fr' ? 'Aucune note supplémentaire' : 'No additional notes')}`,
      '',
      language === 'fr' ? '▸ CONTACT PRÉFÉRÉ' : '▸ PREFERRED CONTACT',
      `  ${language === 'fr' ? 'Méthode' : 'Method'}: ${contactLabel}`,
    ];

    if (socialHandle && (preferredContact === 'instagram' || preferredContact === 'tiktok')) {
      lines.push(`  ${language === 'fr' ? 'Identifiant' : 'Handle'}: @${socialHandle.replace('@', '')}`);
    }

    lines.push('');
    lines.push('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    lines.push(language === 'fr' ? 'Envoyé depuis l\'application Théo Picture' : 'Sent from Théo Picture App');

    return lines.join('\n');
  };

  const openMailComposer = () => {
    hapticLight();
    const subject = encodeURIComponent(
      language === 'fr'
        ? 'Théo Picture — Nouvelle demande de photographie'
        : 'Théo Picture — New Photography Request'
    );
    const body = encodeURIComponent(buildEmailBody());
    const mailtoUrl = `mailto:${DESTINATION_EMAIL}?subject=${subject}&body=${body}`;
    Linking.openURL(mailtoUrl);
  };

  const handleSubmit = async () => {
    if (!name.trim() || !email.trim() || !selectedService) {
      hapticError();
      Alert.alert(t('booking.requiredFields'), t('booking.requiredFieldsMessage'));
      return;
    }

    const subject = encodeURIComponent(
      language === 'fr'
        ? 'Théo Picture — Nouvelle demande de photographie'
        : 'Théo Picture — New Photography Request'
    );
    const body = encodeURIComponent(buildEmailBody());
    const mailtoUrl = `mailto:${DESTINATION_EMAIL}?subject=${subject}&body=${body}`;

    try {
      const canOpen = await Linking.canOpenURL(mailtoUrl);
      if (canOpen) {
        await Linking.openURL(mailtoUrl);
        hapticSuccess();
        setIsSubmitted(true);
      } else {
        hapticError();
        Alert.alert(t('booking.emailNotAvailable'), t('booking.emailNotAvailableMessage'), [{ text: 'OK' }]);
      }
    } catch {
      hapticError();
      Alert.alert(
        'Error',
        language === 'fr'
          ? 'Une erreur s\'est produite. Veuillez réessayer ou contacter Theodore.beaupre@icloud.com directement.'
          : 'Something went wrong. Please try again or contact Theodore.beaupre@icloud.com directly.',
        [{ text: 'OK' }]
      );
    }
  };

  const handleClose = () => {
    hapticLight();
    router.back();
  };

  const openInstagramDM = () => {
    hapticMedium();
    Linking.openURL('https://instagram.com/theo_totk');
  };

  const openTikTokDM = () => {
    hapticMedium();
    Linking.openURL('https://tiktok.com/@theo_totk');
  };

  return (
    <View className="flex-1 bg-brand-black">
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        className="flex-1"
      >
        {/* Header */}
        <View
          className="px-6 pb-4 flex-row items-center justify-between border-b border-brand-charcoal"
          style={{ paddingTop: insets.top + 12 }}
        >
          <View>
            <Text className="text-brand-white text-xl font-light">
              {t('booking.title')}
            </Text>
            {params.serviceTitle && (
              <Text className="text-brand-gold text-sm mt-1">
                {params.serviceTitle}
              </Text>
            )}
          </View>
          <Pressable
            onPress={handleClose}
            className="w-10 h-10 rounded-full bg-brand-charcoal items-center justify-center active:opacity-70"
          >
            <X size={20} color="#8A8A8A" />
          </Pressable>
        </View>

        <ScrollView
          className="flex-1"
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: insets.bottom + 40 }}
          keyboardShouldPersistTaps="handled"
        >
          {isSubmitted ? (
            <Animated.View
              entering={FadeIn.duration(400)}
              className="flex-1 items-center px-6 py-12"
            >
              {/* Success Icon */}
              <View className="w-24 h-24 rounded-full bg-brand-gold/20 items-center justify-center mb-6">
                <Check size={48} color="#C9A962" />
              </View>

              {/* Success Message */}
              <Text className="text-brand-white text-2xl font-light text-center">
                {t('booking.requestSent')}
              </Text>
              <Text className="text-brand-muted text-center mt-3 leading-6 px-4">
                {t('booking.requestSentMessage')}
              </Text>

              {/* Quick Actions */}
              <View className="w-full mt-10">
                <Text className="text-brand-gold text-xs tracking-[3px] uppercase mb-4 text-center">
                  {t('booking.quickActions')}
                </Text>

                {/* Open Mail Button */}
                <Pressable
                  onPress={openMailComposer}
                  className="bg-brand-gold py-4 rounded-xl flex-row items-center justify-center mb-3 active:opacity-80"
                >
                  <Mail size={18} color="#0A0A0A" />
                  <Text className="text-brand-black font-semibold text-base ml-2">
                    {t('booking.openMail')}
                  </Text>
                </Pressable>

                {/* Social DM Buttons */}
                <View className="flex-row space-x-3">
                  <Pressable
                    onPress={openInstagramDM}
                    className="flex-1 bg-brand-charcoal py-4 rounded-xl flex-row items-center justify-center active:opacity-80"
                  >
                    <InstagramIcon size={18} color="#FAFAFA" />
                    <Text className="text-brand-white font-medium text-sm ml-2">
                      DM @theo_totk
                    </Text>
                  </Pressable>

                  <Pressable
                    onPress={openTikTokDM}
                    className="flex-1 bg-brand-charcoal py-4 rounded-xl flex-row items-center justify-center active:opacity-80"
                  >
                    <TikTokIcon size={18} color="#FAFAFA" />
                    <Text className="text-brand-white font-medium text-sm ml-2">
                      DM @theo_totk
                    </Text>
                  </Pressable>
                </View>
              </View>

              {/* Done Button */}
              <Pressable
                onPress={handleClose}
                className="mt-10 active:opacity-70"
              >
                <Text className="text-brand-muted text-sm">
                  {t('common.done')}
                </Text>
              </Pressable>
            </Animated.View>
          ) : (
            <View className="px-6 pt-6">
              {/* Form Fields */}
              <View className="space-y-5">
                {/* Name */}
                <Animated.View entering={FadeInDown.duration(400).delay(0)}>
                  <Text className="text-brand-muted text-xs uppercase tracking-wide mb-2">
                    {t('booking.fullName')} *
                  </Text>
                  <TextInput
                    value={name}
                    onChangeText={setName}
                    placeholder={t('booking.fullNamePlaceholder')}
                    placeholderTextColor="#4A4A4A"
                    className="bg-brand-charcoal text-brand-white px-4 py-4 rounded-xl text-base"
                    autoCapitalize="words"
                  />
                </Animated.View>

                {/* Email */}
                <Animated.View entering={FadeInDown.duration(400).delay(50)}>
                  <Text className="text-brand-muted text-xs uppercase tracking-wide mb-2">
                    {t('booking.email')} *
                  </Text>
                  <TextInput
                    value={email}
                    onChangeText={setEmail}
                    placeholder={t('booking.emailPlaceholder')}
                    placeholderTextColor="#4A4A4A"
                    className="bg-brand-charcoal text-brand-white px-4 py-4 rounded-xl text-base"
                    keyboardType="email-address"
                    autoCapitalize="none"
                  />
                </Animated.View>

                {/* Service Selector */}
                <Animated.View entering={FadeInDown.duration(400).delay(100)}>
                  <Text className="text-brand-muted text-xs uppercase tracking-wide mb-2">
                    {t('booking.service')} *
                  </Text>
                  <Pressable
                    onPress={() => {
                      hapticLight();
                      setShowServicePicker(!showServicePicker);
                      setShowContactPicker(false);
                    }}
                    className="bg-brand-charcoal px-4 py-4 rounded-xl flex-row items-center justify-between"
                  >
                    <Text
                      className={`text-base ${
                        selectedService ? 'text-brand-white' : 'text-brand-gray'
                      }`}
                    >
                      {selectedServiceLabel}
                    </Text>
                    <ChevronDown
                      size={18}
                      color="#8A8A8A"
                      style={{
                        transform: [{ rotate: showServicePicker ? '180deg' : '0deg' }],
                      }}
                    />
                  </Pressable>

                  {showServicePicker && (
                    <Animated.View
                      entering={FadeIn.duration(200)}
                      exiting={FadeOut.duration(200)}
                      className="bg-brand-dark rounded-xl mt-2 overflow-hidden border border-brand-charcoal"
                    >
                      {SERVICE_OPTIONS.map((option, index) => (
                        <Pressable
                          key={option.id}
                          onPress={() => {
                            if (option.unavailable) return;
                            setSelectedService(option.id);
                            setShowServicePicker(false);
                            hapticSelection();
                          }}
                          disabled={option.unavailable}
                          className={`px-4 py-3.5 ${
                            index !== SERVICE_OPTIONS.length - 1
                              ? 'border-b border-brand-charcoal'
                              : ''
                          } ${selectedService === option.id ? 'bg-brand-charcoal' : ''} ${option.unavailable ? 'opacity-50' : ''}`}
                        >
                          <Text
                            className={`text-base ${
                              option.unavailable
                                ? 'text-brand-gray'
                                : selectedService === option.id
                                ? 'text-brand-gold'
                                : 'text-brand-light'
                            }`}
                          >
                            {t(option.labelKey)}
                            {option.unavailable && ` (${t('services.unavailable')})`}
                          </Text>
                        </Pressable>
                      ))}
                    </Animated.View>
                  )}
                </Animated.View>

                {/* Date */}
                <Animated.View entering={FadeInDown.duration(400).delay(150)}>
                  <Text className="text-brand-muted text-xs uppercase tracking-wide mb-2">
                    {t('booking.preferredDate')}
                  </Text>
                  <View className="flex-row items-center bg-brand-charcoal rounded-xl">
                    <View className="pl-4">
                      <Calendar size={18} color="#8A8A8A" />
                    </View>
                    <TextInput
                      value={date}
                      onChangeText={setDate}
                      placeholder={t('booking.datePlaceholder')}
                      placeholderTextColor="#4A4A4A"
                      className="flex-1 text-brand-white px-3 py-4 text-base"
                    />
                  </View>
                </Animated.View>

                {/* Location */}
                <Animated.View entering={FadeInDown.duration(400).delay(200)}>
                  <Text className="text-brand-muted text-xs uppercase tracking-wide mb-2">
                    {t('booking.location')}
                  </Text>
                  <View className="flex-row items-center bg-brand-charcoal rounded-xl">
                    <View className="pl-4">
                      <MapPin size={18} color="#8A8A8A" />
                    </View>
                    <TextInput
                      value={location}
                      onChangeText={setLocation}
                      placeholder={t('booking.locationPlaceholder')}
                      placeholderTextColor="#4A4A4A"
                      className="flex-1 text-brand-white px-3 py-4 text-base"
                    />
                  </View>
                </Animated.View>

                {/* Budget */}
                <Animated.View entering={FadeInDown.duration(400).delay(250)}>
                  <Text className="text-brand-muted text-xs uppercase tracking-wide mb-2">
                    {t('booking.budget')}
                  </Text>
                  <View className="flex-row items-center bg-brand-charcoal rounded-xl">
                    <View className="pl-4">
                      <DollarSign size={18} color="#8A8A8A" />
                    </View>
                    <TextInput
                      value={budget}
                      onChangeText={setBudget}
                      placeholder={t('booking.budgetPlaceholder')}
                      placeholderTextColor="#4A4A4A"
                      className="flex-1 text-brand-white px-3 py-4 text-base"
                      keyboardType="numeric"
                    />
                  </View>
                </Animated.View>

                {/* Notes */}
                <Animated.View entering={FadeInDown.duration(400).delay(300)}>
                  <Text className="text-brand-muted text-xs uppercase tracking-wide mb-2">
                    {t('booking.projectNotes')}
                  </Text>
                  <TextInput
                    value={notes}
                    onChangeText={setNotes}
                    placeholder={t('booking.projectNotesPlaceholder')}
                    placeholderTextColor="#4A4A4A"
                    className="bg-brand-charcoal text-brand-white px-4 py-4 rounded-xl text-base"
                    multiline
                    numberOfLines={4}
                    textAlignVertical="top"
                    style={{ minHeight: 100 }}
                  />
                </Animated.View>

                {/* Preferred Contact Method */}
                <Animated.View entering={FadeInDown.duration(400).delay(350)}>
                  <Text className="text-brand-muted text-xs uppercase tracking-wide mb-2">
                    {t('booking.preferredContact')}
                  </Text>
                  <Pressable
                    onPress={() => {
                      hapticLight();
                      setShowContactPicker(!showContactPicker);
                      setShowServicePicker(false);
                    }}
                    className="bg-brand-charcoal px-4 py-4 rounded-xl flex-row items-center justify-between"
                  >
                    <Text className="text-brand-white text-base">
                      {selectedContactLabel}
                    </Text>
                    <ChevronDown
                      size={18}
                      color="#8A8A8A"
                      style={{
                        transform: [{ rotate: showContactPicker ? '180deg' : '0deg' }],
                      }}
                    />
                  </Pressable>

                  {showContactPicker && (
                    <Animated.View
                      entering={FadeIn.duration(200)}
                      exiting={FadeOut.duration(200)}
                      className="bg-brand-dark rounded-xl mt-2 overflow-hidden border border-brand-charcoal"
                    >
                      {CONTACT_METHOD_OPTIONS.map((option, index) => (
                        <Pressable
                          key={option.id}
                          onPress={() => {
                            setPreferredContact(option.id);
                            setShowContactPicker(false);
                            hapticSelection();
                          }}
                          className={`px-4 py-3.5 ${
                            index !== CONTACT_METHOD_OPTIONS.length - 1
                              ? 'border-b border-brand-charcoal'
                              : ''
                          } ${preferredContact === option.id ? 'bg-brand-charcoal' : ''}`}
                        >
                          <Text
                            className={`text-base ${
                              preferredContact === option.id
                                ? 'text-brand-gold'
                                : 'text-brand-light'
                            }`}
                          >
                            {option.label}
                          </Text>
                        </Pressable>
                      ))}
                    </Animated.View>
                  )}
                </Animated.View>

                {/* Social Handle (conditional) */}
                {(preferredContact === 'instagram' || preferredContact === 'tiktok') && (
                  <Animated.View entering={FadeIn.duration(300)}>
                    <Text className="text-brand-muted text-xs uppercase tracking-wide mb-2">
                      {preferredContact === 'instagram' ? 'Instagram' : 'TikTok'} {t('booking.socialHandle')}
                    </Text>
                    <View className="flex-row items-center bg-brand-charcoal rounded-xl">
                      <View className="pl-4">
                        <AtSign size={18} color="#8A8A8A" />
                      </View>
                      <TextInput
                        value={socialHandle}
                        onChangeText={setSocialHandle}
                        placeholder={t('booking.socialHandlePlaceholder')}
                        placeholderTextColor="#4A4A4A"
                        className="flex-1 text-brand-white px-3 py-4 text-base"
                        autoCapitalize="none"
                        autoCorrect={false}
                      />
                    </View>
                  </Animated.View>
                )}

                {/* Submit Button */}
                <Animated.View entering={FadeInDown.duration(400).delay(400)}>
                  <Pressable
                    onPress={handleSubmit}
                    className="bg-brand-gold py-4 rounded-xl flex-row items-center justify-center mt-2 active:opacity-80"
                  >
                    <Send size={18} color="#0A0A0A" />
                    <Text className="text-brand-black font-semibold text-base ml-2">
                      {t('booking.sendRequest')}
                    </Text>
                  </Pressable>
                </Animated.View>
              </View>

              {/* Quick Contact */}
              <Animated.View
                entering={FadeIn.duration(400).delay(450)}
                className="mt-10 pt-6 border-t border-brand-charcoal"
              >
                <Text className="text-brand-muted text-center text-sm mb-4">
                  {t('booking.orReachOut')}
                </Text>
                <View className="flex-row justify-center space-x-4">
                  <Pressable
                    onPress={() => {
                      hapticLight();
                      Linking.openURL('https://instagram.com/theo_totk');
                    }}
                    className="bg-brand-charcoal px-5 py-3 rounded-full flex-row items-center active:opacity-80"
                  >
                    <InstagramIcon size={18} color="#FAFAFA" />
                    <Text className="text-brand-white text-sm font-medium ml-2">
                      Instagram
                    </Text>
                  </Pressable>
                  <Pressable
                    onPress={() => {
                      hapticLight();
                      Linking.openURL(`mailto:${DESTINATION_EMAIL}`);
                    }}
                    className="bg-brand-charcoal px-5 py-3 rounded-full flex-row items-center active:opacity-80"
                  >
                    <Mail size={16} color="#FAFAFA" />
                    <Text className="text-brand-white text-sm font-medium ml-2">
                      {language === 'fr' ? 'Courriel' : 'Email'}
                    </Text>
                  </Pressable>
                </View>

                {/* Social Footer */}
                <View className="mt-6 items-center">
                  <Text className="text-brand-gray text-xs mb-3">
                    {t('home.followWork')}
                  </Text>
                  <View className="flex-row space-x-6">
                    <Pressable
                      onPress={() => {
                        hapticLight();
                        Linking.openURL('https://instagram.com/theo_totk');
                      }}
                      className="active:opacity-70"
                    >
                      <InstagramIcon size={24} color="#8A8A8A" />
                    </Pressable>
                    <Pressable
                      onPress={() => {
                        hapticLight();
                        Linking.openURL('https://tiktok.com/@theo_totk');
                      }}
                      className="active:opacity-70"
                    >
                      <TikTokIcon size={24} color="#8A8A8A" />
                    </Pressable>
                  </View>
                </View>
              </Animated.View>
            </View>
          )}
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}
