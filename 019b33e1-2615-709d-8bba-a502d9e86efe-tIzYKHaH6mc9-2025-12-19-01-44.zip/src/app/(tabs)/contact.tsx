import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  Pressable,
  Linking,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Mail, MapPin, Copy, Check, ArrowUpRight } from 'lucide-react-native';
import Animated, { FadeInDown, FadeIn } from 'react-native-reanimated';
import * as Clipboard from 'expo-clipboard';
import { hapticLight, hapticSuccess } from '@/lib/haptics';
import { useLanguage } from '@/lib/language-context';

const EMAIL = 'Theodore.beaupre@icloud.com';

// Custom Instagram icon component
function InstagramIcon({ size = 20, color = '#FAFAFA' }: { size?: number; color?: string }) {
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <View
        style={{
          width: size * 0.85,
          height: size * 0.85,
          borderRadius: size * 0.22,
          borderWidth: 1.5,
          borderColor: color,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <View
          style={{
            width: size * 0.35,
            height: size * 0.35,
            borderRadius: size * 0.175,
            borderWidth: 1.5,
            borderColor: color,
          }}
        />
        <View
          style={{
            position: 'absolute',
            top: size * 0.12,
            right: size * 0.12,
            width: size * 0.12,
            height: size * 0.12,
            borderRadius: size * 0.06,
            backgroundColor: color,
          }}
        />
      </View>
    </View>
  );
}

// Custom TikTok icon component
function TikTokIcon({ size = 20, color = '#FAFAFA' }: { size?: number; color?: string }) {
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ fontSize: size * 0.7, color, fontWeight: '700' }}>♪</Text>
    </View>
  );
}

export default function ContactScreen() {
  const insets = useSafeAreaInsets();
  const [emailCopied, setEmailCopied] = useState(false);
  const { t, language } = useLanguage();

  const handleEmailPress = () => {
    hapticLight();
    Linking.openURL(`mailto:${EMAIL}`);
  };

  const handleCopyEmail = async () => {
    await Clipboard.setStringAsync(EMAIL);
    hapticSuccess();
    setEmailCopied(true);
    setTimeout(() => setEmailCopied(false), 2000);
  };

  const handleInstagram = () => {
    hapticLight();
    Linking.openURL('https://instagram.com/theo_totk');
  };

  const handleTikTok = () => {
    hapticLight();
    Linking.openURL('https://tiktok.com/@theo_totk');
  };

  return (
    <View className="flex-1 bg-brand-black">
      <ScrollView
        className="flex-1"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: insets.bottom + 100 }}
      >
        {/* Header */}
        <View className="px-6" style={{ paddingTop: insets.top + 16 }}>
          <Animated.View entering={FadeInDown.duration(600)}>
            <Text className="text-brand-gold text-xs tracking-[3px] uppercase mb-2">
              {t('contact.title')}
            </Text>
            <Text className="text-brand-white text-3xl font-light">
              {t('contact.subtitle')}
            </Text>
            <Text className="text-brand-muted text-base mt-3 font-light leading-6">
              {language === 'fr'
                ? 'Prêt à créer quelque chose de beau ?\nConnectons-nous et discutons de votre projet.'
                : "Ready to create something beautiful?\nLet's connect and discuss your project."}
            </Text>
          </Animated.View>
        </View>

        {/* Owner Info Card */}
        <Animated.View entering={FadeInDown.duration(600).delay(100)} className="px-6 mt-8">
          <View className="bg-brand-charcoal rounded-2xl p-6">
            <View className="flex-row items-center mb-4">
              <View className="w-14 h-14 rounded-full bg-brand-gold/20 items-center justify-center">
                <Text className="text-brand-gold text-xl font-light">TB</Text>
              </View>
              <View className="ml-4">
                <Text className="text-brand-white text-lg font-medium">
                  {t('common.theoName')}
                </Text>
                <Text className="text-brand-gold text-sm mt-0.5">
                  {t('common.theoPicture')}
                </Text>
              </View>
            </View>
            <View className="flex-row items-center">
              <MapPin size={14} color="#8A8A8A" strokeWidth={1.5} />
              <Text className="text-brand-muted text-sm ml-2">
                {t('common.location')}
              </Text>
            </View>
          </View>
        </Animated.View>

        {/* Email Card */}
        <Animated.View entering={FadeInDown.duration(600).delay(200)} className="px-6 mt-4">
          <View className="bg-brand-charcoal rounded-2xl p-5">
            <View className="flex-row items-center mb-4">
              <View className="w-10 h-10 rounded-full bg-brand-gray items-center justify-center">
                <Mail size={18} color="#C9A962" strokeWidth={1.5} />
              </View>
              <View className="ml-3 flex-1">
                <Text className="text-brand-muted text-xs uppercase tracking-wide">
                  {t('contact.email')}
                </Text>
                <Text className="text-brand-light text-base mt-0.5">
                  {EMAIL}
                </Text>
              </View>
            </View>

            <View className="flex-row space-x-3">
              <Pressable
                onPress={handleEmailPress}
                className="flex-1 bg-brand-gold py-3.5 rounded-xl flex-row items-center justify-center active:opacity-80"
              >
                <Mail size={16} color="#0A0A0A" strokeWidth={2} />
                <Text className="text-brand-black font-semibold text-sm ml-2">
                  {language === 'fr' ? 'M\'écrire' : 'Email me'}
                </Text>
              </Pressable>

              <Pressable
                onPress={handleCopyEmail}
                className="bg-brand-gray px-5 py-3.5 rounded-xl flex-row items-center justify-center active:opacity-80"
              >
                {emailCopied ? (
                  <>
                    <Check size={16} color="#C9A962" strokeWidth={2} />
                    <Text className="text-brand-gold font-medium text-sm ml-2">
                      {t('contact.copied')}
                    </Text>
                  </>
                ) : (
                  <>
                    <Copy size={16} color="#FAFAFA" strokeWidth={1.5} />
                    <Text className="text-brand-white font-medium text-sm ml-2">
                      {t('contact.copyEmail')}
                    </Text>
                  </>
                )}
              </Pressable>
            </View>
          </View>
        </Animated.View>

        {/* Social Media Section */}
        <Animated.View entering={FadeInDown.duration(600).delay(300)} className="px-6 mt-8">
          <Text className="text-brand-gold text-xs tracking-[3px] uppercase mb-4">
            {t('contact.socialMedia')}
          </Text>

          {/* Instagram Card */}
          <Pressable
            onPress={handleInstagram}
            className="bg-brand-charcoal rounded-2xl p-5 mb-3 active:opacity-90"
          >
            <View className="flex-row items-center justify-between">
              <View className="flex-row items-center">
                <View className="w-12 h-12 rounded-xl bg-brand-gray items-center justify-center">
                  <InstagramIcon size={24} color="#C9A962" />
                </View>
                <View className="ml-4">
                  <Text className="text-brand-white text-base font-medium">
                    Instagram
                  </Text>
                  <Text className="text-brand-muted text-sm mt-0.5">
                    @theo_totk
                  </Text>
                </View>
              </View>
              <View className="bg-brand-gray px-4 py-2.5 rounded-full flex-row items-center">
                <Text className="text-brand-white text-sm font-medium mr-1.5">
                  DM
                </Text>
                <ArrowUpRight size={14} color="#FAFAFA" />
              </View>
            </View>
          </Pressable>

          {/* TikTok Card */}
          <Pressable
            onPress={handleTikTok}
            className="bg-brand-charcoal rounded-2xl p-5 active:opacity-90"
          >
            <View className="flex-row items-center justify-between">
              <View className="flex-row items-center">
                <View className="w-12 h-12 rounded-xl bg-brand-gray items-center justify-center">
                  <TikTokIcon size={24} color="#C9A962" />
                </View>
                <View className="ml-4">
                  <Text className="text-brand-white text-base font-medium">
                    TikTok
                  </Text>
                  <Text className="text-brand-muted text-sm mt-0.5">
                    @theo_totk
                  </Text>
                </View>
              </View>
              <View className="bg-brand-gray px-4 py-2.5 rounded-full flex-row items-center">
                <Text className="text-brand-white text-sm font-medium mr-1.5">
                  DM
                </Text>
                <ArrowUpRight size={14} color="#FAFAFA" />
              </View>
            </View>
          </Pressable>
        </Animated.View>

        {/* Quick Actions */}
        <Animated.View entering={FadeIn.duration(600).delay(400)} className="px-6 mt-10">
          <Text className="text-brand-muted text-center text-sm mb-4">
            {t('home.followWork')}
          </Text>
          <View className="flex-row justify-center space-x-4">
            <Pressable
              onPress={handleInstagram}
              className="bg-brand-charcoal w-14 h-14 rounded-full items-center justify-center active:opacity-70"
            >
              <InstagramIcon size={24} color="#FAFAFA" />
            </Pressable>
            <Pressable
              onPress={handleTikTok}
              className="bg-brand-charcoal w-14 h-14 rounded-full items-center justify-center active:opacity-70"
            >
              <TikTokIcon size={24} color="#FAFAFA" />
            </Pressable>
          </View>
        </Animated.View>

        {/* Footer */}
        <Animated.View entering={FadeIn.duration(600).delay(500)} className="px-6 mt-12">
          <View className="border-t border-brand-charcoal pt-6">
            <Text className="text-brand-gray text-center text-xs">
              {t('common.copyright')}
            </Text>
          </View>
        </Animated.View>
      </ScrollView>
    </View>
  );
}
