import React, { useEffect } from 'react';
import { View, Text, ScrollView, Pressable, Dimensions, ImageBackground, Linking } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { ChevronDown, Building2, Mountain, Plane, Star, ArrowRight, Settings } from 'lucide-react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  withSequence,
  FadeInDown,
  FadeIn,
} from 'react-native-reanimated';
import { useRouter } from 'expo-router';
import { hapticMedium, hapticLight } from '@/lib/haptics';
import { useLanguage } from '@/lib/language-context';

const { height: SCREEN_HEIGHT, width: SCREEN_WIDTH } = Dimensions.get('window');

// Custom Instagram icon component
function InstagramIcon({ size = 20, color = '#FAFAFA' }: { size?: number; color?: string }) {
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <View
        style={{
          width: size * 0.85,
          height: size * 0.85,
          borderRadius: size * 0.22,
          borderWidth: 1.5,
          borderColor: color,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <View
          style={{
            width: size * 0.35,
            height: size * 0.35,
            borderRadius: size * 0.175,
            borderWidth: 1.5,
            borderColor: color,
          }}
        />
        <View
          style={{
            position: 'absolute',
            top: size * 0.12,
            right: size * 0.12,
            width: size * 0.12,
            height: size * 0.12,
            borderRadius: size * 0.06,
            backgroundColor: color,
          }}
        />
      </View>
    </View>
  );
}

// Custom TikTok icon component
function TikTokIcon({ size = 20, color = '#FAFAFA' }: { size?: number; color?: string }) {
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ fontSize: size * 0.7, color, fontWeight: '700' }}>♪</Text>
    </View>
  );
}

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const scrollIndicator = useSharedValue(0);
  const settingsScale = useSharedValue(1);
  const { t, language } = useLanguage();

  const SERVICES = [
    {
      icon: Building2,
      titleKey: 'services.urban.title',
      descKey: 'services.urban.shortDesc',
      price: language === 'fr' ? 'À partir de 60 $' : 'From $60',
    },
    {
      icon: Mountain,
      titleKey: 'services.landscape.title',
      descKey: 'services.landscape.shortDesc',
      price: language === 'fr' ? 'À partir de 70 $' : 'From $70',
    },
    {
      icon: Plane,
      titleKey: 'services.drone.title',
      descKey: 'services.drone.shortDesc',
      price: language === 'fr' ? 'À partir de 90 $' : 'From $90',
    },
  ];

  const TESTIMONIALS = [
    {
      name: 'Sophie Tremblay',
      text: language === 'fr'
        ? 'Théo a magnifiquement capturé notre événement. Chaque photo raconte une histoire.'
        : 'Théo captured our event beautifully. Every photo tells a story.',
      rating: 5,
    },
    {
      name: 'Marc-André Dubois',
      text: language === 'fr'
        ? 'Professionnel, créatif, et a dépassé toutes les attentes.'
        : 'Professional, creative, and delivered beyond expectations.',
      rating: 5,
    },
    {
      name: 'Émilie Gagnon',
      text: language === 'fr'
        ? 'Les images drone de notre propriété étaient absolument époustouflantes.'
        : 'The drone footage of our property was absolutely stunning.',
      rating: 5,
    },
  ];

  useEffect(() => {
    scrollIndicator.value = withRepeat(
      withTiming(10, { duration: 1500 }),
      -1,
      true
    );
    // Subtle pulse animation for settings icon
    settingsScale.value = withRepeat(
      withSequence(
        withTiming(1.1, { duration: 1000 }),
        withTiming(1, { duration: 1000 })
      ),
      -1,
      false
    );
  }, []);

  const scrollIndicatorStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: scrollIndicator.value }],
  }));

  const settingsAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: settingsScale.value }],
  }));

  const handleSettingsPress = () => {
    hapticLight();
    router.push('/settings');
  };

  return (
    <View className="flex-1 bg-brand-black">
      {/* Settings Button - OUTSIDE ScrollView for guaranteed touch response */}
      <Animated.View
        style={[
          settingsAnimatedStyle,
          {
            position: 'absolute',
            top: insets.top + 8,
            right: 16,
            zIndex: 9999,
            elevation: 10,
          }
        ]}
      >
        <Pressable
          onPress={handleSettingsPress}
          hitSlop={{ top: 15, bottom: 15, left: 15, right: 15 }}
          style={({ pressed }) => ({
            width: 44,
            height: 44,
            borderRadius: 22,
            backgroundColor: pressed ? 'rgba(201, 169, 98, 0.3)' : 'rgba(10, 10, 10, 0.6)',
            alignItems: 'center',
            justifyContent: 'center',
            borderWidth: 1,
            borderColor: 'rgba(201, 169, 98, 0.4)',
            opacity: pressed ? 0.8 : 1,
          })}
          accessibilityLabel={t('settings.title')}
          accessibilityRole="button"
        >
          <Settings size={20} color="#FAFAFA" />
        </Pressable>
      </Animated.View>

      <ScrollView
        className="flex-1"
        showsVerticalScrollIndicator={false}
        bounces={true}
      >
        {/* Hero Section */}
        <View style={{ height: SCREEN_HEIGHT * 0.92 }}>
          <ImageBackground
            source={require('../../../assets/image-1766102751.jpeg')}
            style={{ flex: 1 }}
            resizeMode="cover"
          >
            <LinearGradient
              colors={['transparent', 'rgba(10,10,10,0.6)', 'rgba(10,10,10,0.95)']}
              locations={[0, 0.5, 1]}
              style={{ flex: 1, paddingTop: insets.top }}
            >
              <View className="flex-1 justify-end px-6 pb-16">
                <Animated.View entering={FadeInDown.duration(800).delay(200)}>
                  <Text className="text-brand-gold text-sm tracking-[4px] mb-3 uppercase">
                    {t('common.location')}
                  </Text>
                </Animated.View>

                <Animated.View entering={FadeInDown.duration(800).delay(400)}>
                  <Text className="text-brand-white text-5xl font-light tracking-tight mb-1">
                    Théo
                  </Text>
                  <Text className="text-brand-white text-5xl font-extralight tracking-tight">
                    Picture
                  </Text>
                </Animated.View>

                <Animated.View entering={FadeInDown.duration(800).delay(600)}>
                  <Text className="text-brand-muted text-lg mt-4 leading-7 font-light">
                    {t('home.tagline')}
                  </Text>
                </Animated.View>

                <Animated.View entering={FadeIn.duration(800).delay(1000)}>
                  <Pressable
                    onPress={() => {
                      hapticMedium();
                      router.push('/booking');
                    }}
                    className="mt-8 bg-brand-gold/90 self-start px-8 py-4 rounded-full active:opacity-80"
                  >
                    <Text className="text-brand-black font-semibold text-base tracking-wide">
                      {t('home.bookSession')}
                    </Text>
                  </Pressable>
                </Animated.View>

                <Animated.View
                  style={scrollIndicatorStyle}
                  className="absolute bottom-4 self-center"
                >
                  <ChevronDown size={24} color="#8A8A8A" />
                </Animated.View>
              </View>
            </LinearGradient>
          </ImageBackground>
        </View>

        {/* Services Section */}
        <View className="px-6 py-16 bg-brand-black">
          <Animated.View entering={FadeInDown.duration(600)}>
            <Text className="text-brand-gold text-xs tracking-[3px] uppercase mb-2">
              {t('home.servicesTitle')}
            </Text>
            <Text className="text-brand-white text-3xl font-light mb-8">
              {language === 'fr' ? 'Ce que j\'offre' : 'What I Offer'}
            </Text>
          </Animated.View>

          <View className="space-y-4">
            {SERVICES.map((service, index) => (
              <Animated.View
                key={service.titleKey}
                entering={FadeInDown.duration(600).delay(index * 150)}
              >
                <Pressable
                  className="bg-brand-charcoal rounded-2xl p-5 flex-row items-center active:opacity-90"
                  onPress={() => {
                    hapticLight();
                    router.push('/(tabs)/services');
                  }}
                >
                  <View className="w-14 h-14 rounded-full bg-brand-gray items-center justify-center mr-4">
                    <service.icon size={24} color="#C9A962" strokeWidth={1.5} />
                  </View>
                  <View className="flex-1">
                    <Text className="text-brand-white text-lg font-medium">
                      {t(service.titleKey)}
                    </Text>
                    <Text className="text-brand-muted text-sm mt-0.5">
                      {t(service.descKey)}
                    </Text>
                  </View>
                  <View className="items-end">
                    <Text className="text-brand-gold text-base font-medium">
                      {service.price}
                    </Text>
                    <ArrowRight size={16} color="#8A8A8A" className="mt-1" />
                  </View>
                </Pressable>
              </Animated.View>
            ))}
          </View>

          {/* View All Services */}
          <Pressable
            onPress={() => {
              hapticLight();
              router.push('/(tabs)/services');
            }}
            className="mt-6 self-center active:opacity-70"
          >
            <Text className="text-brand-gold text-sm font-medium">
              {t('home.viewAllServices')}
            </Text>
          </Pressable>
        </View>

        {/* Featured Work Preview */}
        <View className="px-6 py-12 bg-brand-dark">
          <Text className="text-brand-gold text-xs tracking-[3px] uppercase mb-2">
            {t('home.featured')}
          </Text>
          <Text className="text-brand-white text-3xl font-light mb-6">
            {t('home.recentWork')}
          </Text>

          <Pressable
            onPress={() => {
              hapticLight();
              router.push('/(tabs)/portfolio');
            }}
            className="active:opacity-90"
          >
            <ImageBackground
              source={require('../../../assets/image-1766102751.jpeg')}
              style={{ height: 220, borderRadius: 16, overflow: 'hidden' }}
              resizeMode="cover"
            >
              <LinearGradient
                colors={['transparent', 'rgba(10,10,10,0.8)']}
                style={{ flex: 1, justifyContent: 'flex-end', padding: 20 }}
              >
                <Text className="text-brand-white text-xl font-medium">
                  {t('home.droneCollection')}
                </Text>
                <Text className="text-brand-muted text-sm mt-1">
                  {t('home.viewPortfolio')}
                </Text>
              </LinearGradient>
            </ImageBackground>
          </Pressable>
        </View>

        {/* Testimonials Section */}
        <View className="px-6 py-16 bg-brand-black">
          <Text className="text-brand-gold text-xs tracking-[3px] uppercase mb-2">
            {t('home.testimonials')}
          </Text>
          <Text className="text-brand-white text-3xl font-light mb-8">
            {language === 'fr' ? 'Témoignages clients' : 'Client Stories'}
          </Text>

          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            style={{ flexGrow: 0 }}
            contentContainerStyle={{ paddingRight: 24 }}
          >
            {TESTIMONIALS.map((testimonial) => (
              <View
                key={testimonial.name}
                className="bg-brand-charcoal rounded-2xl p-6 mr-4"
                style={{ width: SCREEN_WIDTH * 0.75 }}
              >
                <View className="flex-row mb-3">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} size={14} color="#C9A962" fill="#C9A962" />
                  ))}
                </View>
                <Text className="text-brand-light text-base leading-6 mb-4 font-light">
                  "{testimonial.text}"
                </Text>
                <Text className="text-brand-gold text-sm font-medium">
                  {testimonial.name}
                </Text>
              </View>
            ))}
          </ScrollView>
        </View>

        {/* CTA Section */}
        <View className="px-6 py-16 bg-brand-charcoal">
          <View className="items-center">
            <Text className="text-brand-white text-2xl font-light text-center mb-3">
              {t('home.readyToCreate')}
            </Text>
            <Text className="text-brand-muted text-center text-base mb-6 leading-6">
              {t('home.readyToCreateSub')}
            </Text>
            <Pressable
              onPress={() => {
                hapticMedium();
                router.push('/booking');
              }}
              className="bg-brand-gold px-10 py-4 rounded-full active:opacity-80"
            >
              <Text className="text-brand-black font-semibold text-base">
                {t('home.getInTouch')}
              </Text>
            </Pressable>
          </View>
        </View>

        {/* Footer */}
        <View className="px-6 py-8 bg-brand-black items-center" style={{ paddingBottom: insets.bottom + 100 }}>
          <Text className="text-brand-muted text-sm mb-4">
            {t('common.theoPicture')}
          </Text>

          {/* Social Icons */}
          <View className="flex-row space-x-5 mb-4">
            <Pressable
              onPress={() => {
                hapticLight();
                Linking.openURL('https://instagram.com/theo_totk');
              }}
              className="active:opacity-70"
            >
              <InstagramIcon size={22} color="#8A8A8A" />
            </Pressable>
            <Pressable
              onPress={() => {
                hapticLight();
                Linking.openURL('https://tiktok.com/@theo_totk');
              }}
              className="active:opacity-70"
            >
              <TikTokIcon size={22} color="#8A8A8A" />
            </Pressable>
          </View>

          <Text className="text-brand-gray text-xs">
            {t('common.location')}
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}
