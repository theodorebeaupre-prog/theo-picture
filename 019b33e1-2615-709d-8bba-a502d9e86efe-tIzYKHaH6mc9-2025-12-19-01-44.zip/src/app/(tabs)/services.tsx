import React from 'react';
import {
  View,
  Text,
  ScrollView,
  Pressable,
  Linking,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  Building2,
  Mountain,
  Plane,
  Landmark,
  Sparkles,
  Check,
  ArrowRight,
} from 'lucide-react-native';
import Animated, { FadeInDown, FadeIn } from 'react-native-reanimated';
import { useRouter } from 'expo-router';
import { hapticLight, hapticMedium } from '@/lib/haptics';
import { useLanguage } from '@/lib/language-context';

interface Service {
  id: string;
  titleKey: string;
  descKey: string;
  price: string;
  priceNoteKey?: string;
  tagKeys: string[];
  icon: typeof Building2;
  featured?: boolean;
  unavailable?: boolean;
}

const SERVICES: Service[] = [
  {
    id: 'urban',
    titleKey: 'services.urban.title',
    descKey: 'services.urban.description',
    price: '$60',
    priceNoteKey: 'common.cad',
    tagKeys: ['services.tags.urban', 'services.tags.architecture', 'services.tags.night'],
    icon: Building2,
  },
  {
    id: 'landscape',
    titleKey: 'services.landscape.title',
    descKey: 'services.landscape.description',
    price: '$70',
    priceNoteKey: 'common.cad',
    tagKeys: ['services.tags.nature', 'services.tags.sunset', 'services.tags.panorama'],
    icon: Mountain,
  },
  {
    id: 'drone',
    titleKey: 'services.drone.title',
    descKey: 'services.drone.description',
    price: '$90',
    priceNoteKey: 'common.cad',
    tagKeys: ['services.tags.aerial', 'services.tags.cinematic', 'services.tags.pro'],
    icon: Plane,
    unavailable: true,
  },
  {
    id: 'architecture',
    titleKey: 'services.architecture.title',
    descKey: 'services.architecture.description',
    price: '$75',
    priceNoteKey: 'common.cad',
    tagKeys: ['services.tags.realEstate', 'services.tags.commercial', 'services.tags.details'],
    icon: Landmark,
  },
  {
    id: 'custom',
    titleKey: 'services.custom.title',
    descKey: 'services.custom.description',
    price: '',
    priceNoteKey: 'services.onRequest',
    tagKeys: ['services.tags.custom', 'services.tags.flexible'],
    icon: Sparkles,
  },
];

const INCLUDED_KEYS = [
  'services.included.colorGrading',
  'services.included.delivery',
  'services.included.turnaround',
  'services.included.style',
];

export default function ServicesScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { t, language } = useLanguage();

  const handleBook = (service: Service) => {
    hapticMedium();
    router.push({
      pathname: '/booking',
      params: { serviceId: service.id, serviceTitle: t(service.titleKey) },
    });
  };

  return (
    <View className="flex-1 bg-brand-black">
      <ScrollView
        className="flex-1"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: insets.bottom + 100 }}
      >
        {/* Header */}
        <View className="px-6" style={{ paddingTop: insets.top + 12 }}>
          <Animated.View entering={FadeInDown.duration(600)}>
            <Text className="text-brand-gold text-xs tracking-[3px] uppercase mb-1">
              {t('services.title')}
            </Text>
            <Text className="text-brand-white text-3xl font-light">
              {t('services.subtitle')}
            </Text>
            <Text className="text-brand-muted text-base mt-2 font-light leading-6">
              {language === 'fr'
                ? 'Choisissez un forfait ou demandez un devis personnalisé.'
                : 'Choose a package or request a custom quote.'}
            </Text>
          </Animated.View>
        </View>

        {/* Service Cards */}
        <View className="px-6 mt-8 space-y-4">
          {SERVICES.map((service, index) => (
            <Animated.View
              key={service.id}
              entering={FadeInDown.duration(500).delay(index * 100)}
            >
              <Pressable
                onPress={() => !service.unavailable && handleBook(service)}
                className={service.unavailable ? 'opacity-60' : 'active:scale-[0.98]'}
                style={{ transform: [{ scale: 1 }] }}
                disabled={service.unavailable}
              >
                <View
                  className={`rounded-2xl overflow-hidden ${
                    service.unavailable ? 'border border-brand-gray/30' : ''
                  }`}
                >
                  <View className="bg-brand-charcoal p-5">
                    {/* Header Row */}
                    <View className="flex-row items-start justify-between">
                      <View className="flex-row items-center flex-1">
                        <View
                          className={`w-12 h-12 rounded-xl items-center justify-center ${
                            service.unavailable ? 'bg-brand-gray/50' : 'bg-brand-gray'
                          }`}
                        >
                          <service.icon
                            size={22}
                            color={service.unavailable ? '#4A4A4A' : '#8A8A8A'}
                            strokeWidth={1.5}
                          />
                        </View>
                        <View className="ml-4 flex-1">
                          <View className="flex-row items-center">
                            <Text className={`text-lg font-medium ${service.unavailable ? 'text-brand-muted' : 'text-brand-white'}`}>
                              {t(service.titleKey)}
                            </Text>
                            {service.unavailable && (
                              <View className="ml-2 bg-red-500/20 px-2 py-0.5 rounded">
                                <Text className="text-red-400 text-xs font-medium">
                                  {t('services.unavailable')}
                                </Text>
                              </View>
                            )}
                          </View>
                          <Text className={`text-sm mt-1 leading-5 ${service.unavailable ? 'text-brand-gray' : 'text-brand-muted'}`}>
                            {t(service.descKey)}
                          </Text>
                        </View>
                      </View>
                    </View>

                    {/* Tags */}
                    <View className="flex-row flex-wrap mt-4 -mx-1">
                      {service.tagKeys.map((tagKey) => (
                        <View
                          key={tagKey}
                          className={`px-3 py-1.5 rounded-full mx-1 mb-2 ${service.unavailable ? 'bg-brand-gray/30' : 'bg-brand-gray/50'}`}
                        >
                          <Text className={`text-xs ${service.unavailable ? 'text-brand-gray' : 'text-brand-muted'}`}>
                            {t(tagKey)}
                          </Text>
                        </View>
                      ))}
                    </View>

                    {/* Footer */}
                    <View className="flex-row items-center justify-between mt-4 pt-4 border-t border-brand-gray/50">
                      <View className="flex-row items-baseline">
                        {service.price ? (
                          <Text className={`text-2xl font-light ${service.unavailable ? 'text-brand-muted line-through' : 'text-brand-white'}`}>
                            {service.price}
                          </Text>
                        ) : (
                          <Text className="text-2xl font-light text-brand-white">
                            {t('services.quote')}
                          </Text>
                        )}
                        {service.priceNoteKey && (
                          <Text className="text-brand-muted text-sm ml-1">
                            {t(service.priceNoteKey)}
                          </Text>
                        )}
                      </View>
                      {service.unavailable ? (
                        <View className="flex-row items-center px-5 py-2.5 rounded-full bg-brand-gray/30">
                          <Text className="text-brand-gray text-sm font-medium">
                            {t('services.comingSoon')}
                          </Text>
                        </View>
                      ) : (
                        <Pressable
                          onPress={() => handleBook(service)}
                          className="flex-row items-center px-5 py-2.5 rounded-full active:opacity-80 bg-brand-gray"
                        >
                          <Text className="text-sm font-medium text-brand-white">
                            {service.id === 'custom' ? t('services.request') : t('services.book')}
                          </Text>
                          <ArrowRight
                            size={14}
                            color="#FAFAFA"
                            className="ml-1"
                          />
                        </Pressable>
                      )}
                    </View>
                  </View>
                </View>
              </Pressable>
            </Animated.View>
          ))}
        </View>

        {/* What's Included */}
        <Animated.View
          entering={FadeIn.duration(600).delay(600)}
          className="px-6 mt-10"
        >
          <View className="bg-brand-dark rounded-2xl p-6 border border-brand-charcoal">
            <Text className="text-brand-gold text-xs tracking-[3px] uppercase mb-4">
              {t('services.whatsIncluded')}
            </Text>
            <View className="space-y-3">
              {INCLUDED_KEYS.map((key, index) => (
                <View key={index} className="flex-row items-center">
                  <View className="w-6 h-6 rounded-full bg-brand-gold/10 items-center justify-center mr-3">
                    <Check size={12} color="#C9A962" strokeWidth={2.5} />
                  </View>
                  <Text className="text-brand-light text-base font-light flex-1">
                    {t(key)}
                  </Text>
                </View>
              ))}
            </View>
          </View>
        </Animated.View>

        {/* Social CTA */}
        <Animated.View
          entering={FadeIn.duration(600).delay(700)}
          className="px-6 mt-10"
        >
          <View className="items-center">
            <Text className="text-brand-muted text-sm mb-4">
              {t('home.followWork')}
            </Text>
            <View className="flex-row space-x-4">
              <Pressable
                onPress={() => {
                  hapticLight();
                  Linking.openURL('https://instagram.com/theo_totk');
                }}
                className="bg-brand-charcoal px-6 py-3 rounded-full flex-row items-center active:opacity-80"
              >
                <Text className="text-brand-white text-sm font-medium">
                  @theo_totk
                </Text>
              </Pressable>
              <Pressable
                onPress={() => {
                  hapticLight();
                  Linking.openURL('https://tiktok.com/@theo_totk');
                }}
                className="bg-brand-charcoal px-6 py-3 rounded-full flex-row items-center active:opacity-80"
              >
                <Text className="text-brand-white text-sm font-medium">
                  TikTok
                </Text>
              </Pressable>
            </View>
          </View>
        </Animated.View>
      </ScrollView>
    </View>
  );
}
