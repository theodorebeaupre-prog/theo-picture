import React from 'react';
import {
  View,
  Text,
  ScrollView,
  Image,
  Pressable,
  Linking,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Mail, MapPin, Award, Heart, Camera } from 'lucide-react-native';
import Animated, { FadeInDown, FadeIn } from 'react-native-reanimated';
import { hapticLight } from '@/lib/haptics';
import { useLanguage } from '@/lib/language-context';

// Custom Instagram icon component
function InstagramIcon({ size = 20, color = '#FAFAFA' }: { size?: number; color?: string }) {
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <View
        style={{
          width: size * 0.85,
          height: size * 0.85,
          borderRadius: size * 0.22,
          borderWidth: 1.5,
          borderColor: color,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <View
          style={{
            width: size * 0.35,
            height: size * 0.35,
            borderRadius: size * 0.175,
            borderWidth: 1.5,
            borderColor: color,
          }}
        />
        <View
          style={{
            position: 'absolute',
            top: size * 0.12,
            right: size * 0.12,
            width: size * 0.12,
            height: size * 0.12,
            borderRadius: size * 0.06,
            backgroundColor: color,
          }}
        />
      </View>
    </View>
  );
}

// Custom TikTok icon component
function TikTokIcon({ size = 20, color = '#FAFAFA' }: { size?: number; color?: string }) {
  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      <Text style={{ fontSize: size * 0.7, color, fontWeight: '700' }}>♪</Text>
    </View>
  );
}

export default function AboutScreen() {
  const insets = useSafeAreaInsets();
  const { t, language } = useLanguage();

  const STATS = [
    { value: '5+', labelKey: 'about.stats.yearsExperience', icon: Award },
    { value: '100+', labelKey: 'about.stats.projects', icon: Camera },
    { value: '50+', labelKey: 'about.stats.happyClients', icon: Heart },
  ];

  const GEAR = language === 'fr'
    ? [
        'Sony A7IV & A7SIII',
        'DJI Mavic 3 Pro',
        'Objectifs Sigma Art Prime',
        'Kit d\'éclairage professionnel',
      ]
    : [
        'Sony A7IV & A7SIII',
        'DJI Mavic 3 Pro',
        'Sigma Art Prime Lenses',
        'Professional Lighting Kit',
      ];

  const openInstagram = () => {
    hapticLight();
    Linking.openURL('https://instagram.com/theo_totk');
  };

  const openTikTok = () => {
    hapticLight();
    Linking.openURL('https://tiktok.com/@theo_totk');
  };

  const openEmail = () => {
    hapticLight();
    Linking.openURL('mailto:Theodore.beaupre@icloud.com');
  };

  return (
    <View className="flex-1 bg-brand-black">
      <ScrollView
        className="flex-1"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: insets.bottom + 100 }}
      >
        {/* Hero Section with Framed Photo */}
        <View style={{ paddingTop: insets.top + 20 }} className="px-6 items-center">
          {/* Photo Frame */}
          <View
            className="bg-brand-charcoal p-3 rounded-3xl"
            style={{
              shadowColor: '#C9A962',
              shadowOffset: { width: 0, height: 4 },
              shadowOpacity: 0.15,
              shadowRadius: 20,
              elevation: 8,
            }}
          >
            <View className="rounded-2xl overflow-hidden" style={{ width: 280, height: 350 }}>
              <Image
                source={require('../../../assets/image-1766102772.jpeg')}
                style={{ width: '100%', height: '100%' }}
                resizeMode="cover"
              />
            </View>
          </View>

          {/* Gold accent line */}
          <View className="w-16 h-1 bg-brand-gold/40 rounded-full mt-6 mb-2" />
        </View>

        {/* Content */}
        <View className="px-6 mt-6">
          <Animated.View entering={FadeInDown.duration(600)}>
            <Text className="text-brand-gold text-xs tracking-[3px] uppercase mb-2">
              {t('about.title')}
            </Text>
            <Text className="text-brand-white text-4xl font-light mb-1">
              {t('common.theoName')}
            </Text>
            <Text className="text-brand-gold text-base mt-1">
              {t('common.theoPicture')}
            </Text>
            <View className="flex-row items-center mt-3">
              <MapPin size={14} color="#8A8A8A" />
              <Text className="text-brand-muted text-sm ml-1">
                {t('common.location')}
              </Text>
            </View>
          </Animated.View>

          {/* Bio */}
          <Animated.View entering={FadeInDown.duration(600).delay(150)} className="mt-8">
            <Text className="text-brand-light text-lg leading-8 font-light">
              {language === 'fr'
                ? 'Je suis photographe et vidéaste basé dans le magnifique Québec. Ma passion est de capturer des moments authentiques — ceux qui racontent votre histoire sans mots.'
                : "I'm a photographer and videographer based in beautiful Québec. My passion is capturing authentic moments — the ones that tell your story without words."}
            </Text>
            <Text className="text-brand-muted text-base leading-7 mt-4 font-light">
              {language === 'fr'
                ? 'Des paysages urbains aux vues aériennes, j\'apporte un regard cinématographique à chaque projet. Je crois que la grande photographie ne se résume pas aux poses parfaites — il s\'agit des émotions authentiques et de la magie qui se produit entre les prises.'
                : "From urban cityscapes to aerial landscapes, I bring a cinematic eye to every project. I believe great photography isn't about perfect poses — it's about genuine emotions and the magic that happens in between."}
            </Text>
            <Text className="text-brand-muted text-base leading-7 mt-4 font-light">
              {language === 'fr'
                ? 'Quand je ne suis pas derrière l\'appareil, vous me trouverez en train d\'explorer les paysages époustouflants du Québec ou d\'expérimenter de nouvelles techniques créatives.'
                : "When I'm not behind the camera, you'll find me exploring the stunning landscapes of Québec or experimenting with new creative techniques."}
            </Text>
          </Animated.View>

          {/* Stats */}
          <Animated.View
            entering={FadeInDown.duration(600).delay(300)}
            className="flex-row justify-between mt-10 py-8 border-t border-b border-brand-charcoal"
          >
            {STATS.map((stat) => (
              <View key={stat.labelKey} className="items-center flex-1">
                <stat.icon size={20} color="#C9A962" strokeWidth={1.5} />
                <Text className="text-brand-white text-2xl font-light mt-2">
                  {stat.value}
                </Text>
                <Text className="text-brand-muted text-xs mt-1 text-center">
                  {t(stat.labelKey)}
                </Text>
              </View>
            ))}
          </Animated.View>

          {/* Equipment */}
          <Animated.View entering={FadeInDown.duration(600).delay(450)} className="mt-10">
            <Text className="text-brand-gold text-xs tracking-[3px] uppercase mb-4">
              {language === 'fr' ? 'Mon équipement' : 'My Gear'}
            </Text>
            <View className="space-y-3">
              {GEAR.map((item) => (
                <View key={item} className="flex-row items-center">
                  <View className="w-1.5 h-1.5 rounded-full bg-brand-gold mr-3" />
                  <Text className="text-brand-muted text-base">{item}</Text>
                </View>
              ))}
            </View>
          </Animated.View>

          {/* Social Links */}
          <Animated.View
            entering={FadeIn.duration(600).delay(600)}
            className="mt-10"
          >
            <Text className="text-brand-gold text-xs tracking-[3px] uppercase mb-4">
              {language === 'fr' ? 'Connecter' : 'Connect'}
            </Text>
            <View className="flex-row space-x-3">
              <Pressable
                onPress={openInstagram}
                className="flex-1 bg-brand-charcoal py-4 rounded-xl flex-row items-center justify-center active:opacity-80"
              >
                <InstagramIcon size={20} color="#C9A962" />
                <Text className="text-brand-white text-base font-medium ml-2">
                  Instagram
                </Text>
              </Pressable>

              <Pressable
                onPress={openTikTok}
                className="flex-1 bg-brand-charcoal py-4 rounded-xl flex-row items-center justify-center active:opacity-80"
              >
                <TikTokIcon size={20} color="#C9A962" />
                <Text className="text-brand-white text-base font-medium ml-2">
                  TikTok
                </Text>
              </Pressable>
            </View>

            <Pressable
              onPress={openEmail}
              className="mt-3 bg-brand-charcoal py-4 rounded-xl flex-row items-center justify-center active:opacity-80"
            >
              <Mail size={20} color="#C9A962" />
              <Text className="text-brand-white text-base font-medium ml-2">
                {language === 'fr' ? 'M\'envoyer un courriel' : 'Email Me'}
              </Text>
            </Pressable>
          </Animated.View>

          {/* Quote */}
          <Animated.View
            entering={FadeInDown.duration(600).delay(750)}
            className="mt-12 bg-brand-charcoal rounded-2xl p-6"
          >
            <Text className="text-brand-gold text-4xl font-serif">"</Text>
            <Text className="text-brand-light text-lg leading-7 font-light -mt-2">
              {language === 'fr'
                ? 'Chaque image est une opportunité de capturer quelque chose d\'extraordinaire dans l\'ordinaire.'
                : 'Every frame is an opportunity to capture something extraordinary in the ordinary.'}
            </Text>
            <Text className="text-brand-muted text-sm mt-4">
              — Théo
            </Text>
          </Animated.View>

          {/* Footer */}
          <View className="mt-10 pt-6 border-t border-brand-charcoal">
            <Text className="text-brand-gray text-center text-xs">
              {t('common.copyright')}
            </Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}
