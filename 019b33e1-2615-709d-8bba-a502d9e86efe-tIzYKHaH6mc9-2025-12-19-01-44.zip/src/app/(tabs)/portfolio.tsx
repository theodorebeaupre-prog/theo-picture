import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  ScrollView,
  Pressable,
  Dimensions,
  Image,
  Modal,
  StatusBar,
  ImageSourcePropType,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { X, Play, Camera, Video, Plane } from 'lucide-react-native';
import Animated, {
  FadeIn,
  FadeOut,
  FadeInDown,
  ZoomIn,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { hapticLight, hapticSelection, hapticMedium } from '@/lib/haptics';
import { useLanguage } from '@/lib/language-context';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');
const GRID_GAP = 3;
const COLUMN_WIDTH = (SCREEN_WIDTH - GRID_GAP * 3) / 2;

type Category = 'photos' | 'videos' | 'drone';

interface GalleryItem {
  id: string;
  source: ImageSourcePropType;
  category: Category;
  titleKey: string;
  isVideo?: boolean;
}

const GALLERY_ITEMS: GalleryItem[] = [
  // Photos
  { id: '1', source: { uri: 'https://images.unsplash.com/photo-1519741497674-611481863552?w=800&q=80' }, category: 'photos', titleKey: 'portfolio.galleryItems.weddingDay' },
  { id: '2', source: { uri: 'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?w=800&q=80' }, category: 'photos', titleKey: 'portfolio.galleryItems.ceremony' },
  { id: '3', source: { uri: 'https://images.unsplash.com/photo-1606216794074-735e91aa2c92?w=800&q=80' }, category: 'photos', titleKey: 'portfolio.galleryItems.portraitSession' },
  { id: '4', source: { uri: 'https://images.unsplash.com/photo-1529636798458-92182e662485?w=800&q=80' }, category: 'photos', titleKey: 'portfolio.galleryItems.engagement' },
  { id: '5', source: { uri: 'https://images.unsplash.com/photo-1591604466107-ec97de577aff?w=800&q=80' }, category: 'photos', titleKey: 'portfolio.galleryItems.familyPortrait' },
  { id: '6', source: { uri: 'https://images.unsplash.com/photo-1537633552985-df8429e8048b?w=800&q=80' }, category: 'photos', titleKey: 'portfolio.galleryItems.eventCoverage' },
  // Videos
  { id: '7', source: { uri: 'https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?w=800&q=80' }, category: 'videos', titleKey: 'portfolio.galleryItems.weddingFilm', isVideo: true },
  { id: '8', source: { uri: 'https://images.unsplash.com/photo-1536240478700-b869070f9279?w=800&q=80' }, category: 'videos', titleKey: 'portfolio.galleryItems.commercial', isVideo: true },
  { id: '9', source: { uri: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=800&q=80' }, category: 'videos', titleKey: 'portfolio.galleryItems.corporateVideo', isVideo: true },
  { id: '10', source: { uri: 'https://images.unsplash.com/photo-1485846234645-a62644f84728?w=800&q=80' }, category: 'videos', titleKey: 'portfolio.galleryItems.musicVideo', isVideo: true },
  // Drone
  { id: '11', source: require('../../../assets/image-1766102751.jpeg'), category: 'drone', titleKey: 'portfolio.galleryItems.sunsetQuebec' },
  { id: '12', source: { uri: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&q=80' }, category: 'drone', titleKey: 'portfolio.galleryItems.mountainView' },
  { id: '13', source: { uri: 'https://images.unsplash.com/photo-1502472584811-0a2f2feb8968?w=800&q=80' }, category: 'drone', titleKey: 'portfolio.galleryItems.realEstate' },
  { id: '14', source: { uri: 'https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?w=800&q=80' }, category: 'drone', titleKey: 'portfolio.galleryItems.nature' },
];

export default function PortfolioScreen() {
  const insets = useSafeAreaInsets();
  const [activeCategory, setActiveCategory] = useState<Category>('photos');
  const [selectedItem, setSelectedItem] = useState<GalleryItem | null>(null);
  const { t, language } = useLanguage();

  const CATEGORIES: { key: Category; labelKey: string; icon: typeof Camera }[] = [
    { key: 'photos', labelKey: 'portfolio.photos', icon: Camera },
    { key: 'videos', labelKey: 'portfolio.videos', icon: Video },
    { key: 'drone', labelKey: 'portfolio.drone', icon: Plane },
  ];

  const filteredItems = GALLERY_ITEMS.filter(
    (item) => item.category === activeCategory
  );

  const openFullscreen = useCallback((item: GalleryItem) => {
    hapticMedium();
    setSelectedItem(item);
  }, []);

  const closeFullscreen = useCallback(() => {
    hapticLight();
    setSelectedItem(null);
  }, []);

  return (
    <View className="flex-1 bg-brand-black">
      <StatusBar barStyle="light-content" />

      {/* Header */}
      <View
        className="px-6 pb-4 bg-brand-black"
        style={{ paddingTop: insets.top + 12 }}
      >
        <Animated.View entering={FadeInDown.duration(600)}>
          <Text className="text-brand-gold text-xs tracking-[3px] uppercase mb-1">
            {t('portfolio.title')}
          </Text>
          <Text className="text-brand-white text-3xl font-light">
            {language === 'fr' ? 'Mon travail' : 'My Work'}
          </Text>
        </Animated.View>

        {/* Category Tabs */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={{ flexGrow: 0, marginTop: 20 }}
          contentContainerStyle={{ gap: 8 }}
        >
          {CATEGORIES.map((category) => {
            const isActive = activeCategory === category.key;
            const IconComponent = category.icon;
            return (
              <Pressable
                key={category.key}
                onPress={() => {
                  hapticSelection();
                  setActiveCategory(category.key);
                }}
                className={`flex-row items-center px-5 py-3 rounded-full ${
                  isActive ? 'bg-brand-gold' : 'bg-brand-charcoal'
                }`}
              >
                <IconComponent
                  size={16}
                  color={isActive ? '#0A0A0A' : '#8A8A8A'}
                  strokeWidth={isActive ? 2 : 1.5}
                />
                <Text
                  className={`ml-2 text-sm font-medium ${
                    isActive ? 'text-brand-black' : 'text-brand-muted'
                  }`}
                >
                  {t(category.labelKey)}
                </Text>
              </Pressable>
            );
          })}
        </ScrollView>
      </View>

      {/* Gallery Grid */}
      <ScrollView
        className="flex-1"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          paddingHorizontal: GRID_GAP,
          paddingBottom: insets.bottom + 100,
        }}
      >
        {/* Drone Unavailable Notice */}
        {activeCategory === 'drone' && (
          <Animated.View
            entering={FadeIn.duration(300)}
            className="mx-2 mb-4 bg-brand-charcoal rounded-xl p-4 border border-brand-gray/30"
          >
            <Text className="text-brand-muted text-sm text-center">
              {t('portfolio.droneUnavailable')}
            </Text>
          </Animated.View>
        )}

        <View className="flex-row flex-wrap" style={{ gap: GRID_GAP }}>
          {filteredItems.map((item, index) => (
            <Animated.View
              key={item.id}
              entering={FadeIn.duration(400).delay(index * 50)}
            >
              <Pressable
                onPress={() => openFullscreen(item)}
                className="active:opacity-90"
              >
                <Image
                  source={item.source}
                  style={{
                    width: COLUMN_WIDTH,
                    height: index % 3 === 0 ? COLUMN_WIDTH * 1.4 : COLUMN_WIDTH,
                    borderRadius: 4,
                  }}
                  resizeMode="cover"
                />
                {item.isVideo && (
                  <View
                    className="absolute inset-0 items-center justify-center"
                    style={{ backgroundColor: 'rgba(0,0,0,0.3)', borderRadius: 4 }}
                  >
                    <View className="w-12 h-12 rounded-full bg-brand-white/20 items-center justify-center">
                      <Play size={20} color="#FAFAFA" fill="#FAFAFA" />
                    </View>
                  </View>
                )}
              </Pressable>
            </Animated.View>
          ))}
        </View>
      </ScrollView>

      {/* Fullscreen Modal */}
      <Modal
        visible={selectedItem !== null}
        animationType="fade"
        transparent
        statusBarTranslucent
        onRequestClose={closeFullscreen}
      >
        <Animated.View
          entering={FadeIn.duration(200)}
          exiting={FadeOut.duration(200)}
          className="flex-1 bg-brand-black"
        >
          {/* Close Button */}
          <Pressable
            onPress={closeFullscreen}
            className="absolute top-0 right-0 z-10 p-4"
            style={{ paddingTop: insets.top + 16 }}
          >
            <View className="w-10 h-10 rounded-full bg-brand-charcoal/80 items-center justify-center">
              <X size={20} color="#FAFAFA" />
            </View>
          </Pressable>

          {/* Image */}
          {selectedItem && (
            <View className="flex-1 items-center justify-center">
              <Animated.Image
                entering={ZoomIn.duration(300)}
                source={selectedItem.source}
                style={{
                  width: SCREEN_WIDTH,
                  height: SCREEN_HEIGHT * 0.7,
                }}
                resizeMode="contain"
              />

              {/* Caption */}
              <LinearGradient
                colors={['transparent', 'rgba(10,10,10,0.9)']}
                style={{
                  position: 'absolute',
                  bottom: 0,
                  left: 0,
                  right: 0,
                  paddingHorizontal: 24,
                  paddingTop: 60,
                  paddingBottom: insets.bottom + 40,
                }}
              >
                <Text className="text-brand-white text-2xl font-light">
                  {t(selectedItem.titleKey)}
                </Text>
                <Text className="text-brand-muted text-sm mt-1 capitalize">
                  {t(`portfolio.${selectedItem.category}`)}
                </Text>
              </LinearGradient>
            </View>
          )}
        </Animated.View>
      </Modal>
    </View>
  );
}
