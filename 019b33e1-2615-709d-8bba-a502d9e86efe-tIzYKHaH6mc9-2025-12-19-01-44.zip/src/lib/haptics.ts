import * as Haptics from 'expo-haptics';

/**
 * Haptic feedback utilities for the app
 * Provides easy-to-use functions for all available haptic types
 */

// Impact feedback - for touch interactions
export const hapticLight = () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
export const hapticMedium = () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
export const hapticHeavy = () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
export const hapticRigid = () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Rigid);
export const hapticSoft = () => Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Soft);

// Notification feedback - for status changes
export const hapticSuccess = () => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
export const hapticWarning = () => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
export const hapticError = () => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);

// Selection feedback - for scrolling/picking
export const hapticSelection = () => Haptics.selectionAsync();

/**
 * Usage guide:
 *
 * hapticLight    - Subtle UI interactions, light taps, picker changes
 * hapticMedium   - Standard button presses, toggle switches, card swipes
 * hapticHeavy    - Important actions, confirmations, significant UI changes
 * hapticRigid    - Precise interactions, mechanical buttons, snapping to grid
 * hapticSoft     - Gentle interactions, smooth transitions, rubber-like buttons
 *
 * hapticSuccess  - Completed tasks, successful operations, positive confirmations
 * hapticWarning  - Caution messages, alerts, attention-needed states
 * hapticError    - Failed operations, validation errors, critical alerts
 *
 * hapticSelection - Scrolling through lists, moving between items, picker wheels
 */
