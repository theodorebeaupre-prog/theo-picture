export type Language = 'fr' | 'en';

export const translations = {
  // Common
  common: {
    theoName: {
      fr: 'Théodore Beaupré',
      en: 'Théodore Beaupré',
    },
    theoPicture: {
      fr: 'Théo Picture',
      en: 'Théo Picture',
    },
    location: {
      fr: 'Québec, Canada',
      en: 'Québec, Canada',
    },
    cad: {
      fr: 'CAD',
      en: 'CAD',
    },
    done: {
      fr: 'Terminé',
      en: 'Done',
    },
    cancel: {
      fr: 'Annuler',
      en: 'Cancel',
    },
    send: {
      fr: 'Envoyer',
      en: 'Send',
    },
    copyright: {
      fr: '© Théodore Beaupré — Théo Picture',
      en: '© Théodore Beaupré — Théo Picture',
    },
  },

  // Navigation
  nav: {
    home: {
      fr: 'Accueil',
      en: 'Home',
    },
    portfolio: {
      fr: 'Portfolio',
      en: 'Portfolio',
    },
    services: {
      fr: 'Services',
      en: 'Services',
    },
    about: {
      fr: 'À propos',
      en: 'About',
    },
    contact: {
      fr: 'Contact',
      en: 'Contact',
    },
  },

  // Home Screen
  home: {
    tagline: {
      fr: 'Photographie & Vidéographie\nCapturer les moments qui comptent',
      en: 'Photography & Videography\nCapturing moments that matter',
    },
    bookSession: {
      fr: 'Réserver une séance',
      en: 'Book a Session',
    },
    servicesTitle: {
      fr: 'Services',
      en: 'Services',
    },
    viewAllServices: {
      fr: 'Voir tous les services et tarifs',
      en: 'View All Services & Pricing',
    },
    featured: {
      fr: 'À la une',
      en: 'Featured',
    },
    recentWork: {
      fr: 'Travaux récents',
      en: 'Recent Work',
    },
    droneCollection: {
      fr: 'Collection Drone',
      en: 'Drone Collection',
    },
    viewPortfolio: {
      fr: 'Voir le portfolio',
      en: 'View Portfolio',
    },
    testimonials: {
      fr: 'Témoignages',
      en: 'Testimonials',
    },
    readyToCreate: {
      fr: 'Prêt à créer ?',
      en: 'Ready to Create?',
    },
    readyToCreateSub: {
      fr: 'Capturons vos moments spéciaux\navec une excellence cinématographique',
      en: "Let's capture your special moments\nwith cinematic excellence",
    },
    getInTouch: {
      fr: 'Me contacter',
      en: 'Get in Touch',
    },
    followWork: {
      fr: 'Suivez mon travail sur Instagram & TikTok',
      en: 'Follow my work on Instagram & TikTok',
    },
  },

  // Services
  services: {
    title: {
      fr: 'Services',
      en: 'Services',
    },
    subtitle: {
      fr: 'Services et tarifs',
      en: 'Services & Pricing',
    },
    description: {
      fr: 'Photographie & vidéographie professionnelles pour tous vos projets créatifs.',
      en: 'Professional photography & videography for all your creative projects.',
    },
    urban: {
      title: {
        fr: 'Urbain & Ville',
        en: 'Urban & City',
      },
      description: {
        fr: 'Ambiance urbaine, architecture, rues, jour ou nuit.',
        en: 'City vibes, architecture, streets, day or night.',
      },
      shortDesc: {
        fr: 'Architecture, rues, jour ou nuit',
        en: 'Architecture, streets, day or night',
      },
    },
    landscape: {
      title: {
        fr: 'Paysage & Nature',
        en: 'Landscape & Nature',
      },
      description: {
        fr: 'Paysages, lacs, rivières, couchers de soleil, panoramas.',
        en: 'Landscapes, lakes, rivers, sunsets, panoramas.',
      },
      shortDesc: {
        fr: 'Couchers de soleil, lacs, panoramas',
        en: 'Sunsets, lakes, panoramas',
      },
    },
    drone: {
      title: {
        fr: 'Photographie Drone',
        en: 'Drone Photography',
      },
      description: {
        fr: 'Actuellement indisponible — drone en réparation.',
        en: 'Currently unavailable — drone under repair.',
      },
      shortDesc: {
        fr: 'Photos aériennes cinématographiques',
        en: 'Cinematic aerial photos',
      },
    },
    architecture: {
      title: {
        fr: 'Architecture & Bâtiments',
        en: 'Architecture & Buildings',
      },
      description: {
        fr: 'Angles nets, lignes et détails architecturaux.',
        en: 'Clean angles, lines, and building highlights.',
      },
      shortDesc: {
        fr: 'Immobilier, commercial, détails',
        en: 'Real estate, commercial, details',
      },
    },
    custom: {
      title: {
        fr: 'Projet sur mesure',
        en: 'Custom Project',
      },
      description: {
        fr: 'Demandes spéciales et collaborations créatives.',
        en: 'Special requests and creative collaborations.',
      },
      shortDesc: {
        fr: 'Sur mesure, flexible',
        en: 'Custom, flexible',
      },
    },
    startingAt: {
      fr: 'À partir de',
      en: 'From',
    },
    quote: {
      fr: 'Devis',
      en: 'Quote',
    },
    onRequest: {
      fr: 'sur demande',
      en: 'on request',
    },
    book: {
      fr: 'Réserver',
      en: 'Book',
    },
    request: {
      fr: 'Demander',
      en: 'Request',
    },
    unavailable: {
      fr: 'Indisponible',
      en: 'Unavailable',
    },
    comingSoon: {
      fr: 'Bientôt disponible',
      en: 'Coming Soon',
    },
    whatsIncluded: {
      fr: "Ce qui est inclus",
      en: "What's Included",
    },
    included: {
      colorGrading: {
        fr: 'Retouche couleur professionnelle',
        en: 'Professional color grading / retouching',
      },
      delivery: {
        fr: 'Livraison numérique haute résolution',
        en: 'High-resolution digital delivery',
      },
      turnaround: {
        fr: 'Délai de 7 à 14 jours',
        en: '7-14 day turnaround',
      },
      consultation: {
        fr: 'Consultation créative avant le projet',
        en: 'Pre-shoot creative consultation',
      },
      style: {
        fr: 'Style cinématographique signature Théo Picture',
        en: 'Signature Théo Picture cinematic style',
      },
    },
    tags: {
      urban: { fr: 'Urbain', en: 'Urban' },
      architecture: { fr: 'Architecture', en: 'Architecture' },
      night: { fr: 'Nuit', en: 'Night' },
      nature: { fr: 'Nature', en: 'Nature' },
      sunset: { fr: 'Coucher de soleil', en: 'Sunset' },
      panorama: { fr: 'Panorama', en: 'Panorama' },
      aerial: { fr: 'Aérien', en: 'Aerial' },
      cinematic: { fr: 'Cinématographique', en: 'Cinematic' },
      pro: { fr: 'Pro', en: 'Pro' },
      realEstate: { fr: 'Immobilier', en: 'Real estate' },
      commercial: { fr: 'Commercial', en: 'Commercial' },
      details: { fr: 'Détails', en: 'Details' },
      custom: { fr: 'Sur mesure', en: 'Custom' },
      flexible: { fr: 'Flexible', en: 'Flexible' },
    },
  },

  // Portfolio
  portfolio: {
    title: {
      fr: 'Portfolio',
      en: 'Portfolio',
    },
    photos: {
      fr: 'Photos',
      en: 'Photos',
    },
    videos: {
      fr: 'Vidéos',
      en: 'Videos',
    },
    drone: {
      fr: 'Drone',
      en: 'Drone',
    },
    droneUnavailable: {
      fr: 'La photographie par drone est temporairement indisponible pendant la réparation de mon drone. Revenez bientôt !',
      en: 'Drone photography is temporarily unavailable while my drone is being repaired. Check back soon!',
    },
    galleryItems: {
      weddingDay: { fr: 'Jour de mariage', en: 'Wedding Day' },
      ceremony: { fr: 'Cérémonie', en: 'Ceremony' },
      portraitSession: { fr: 'Séance portrait', en: 'Portrait Session' },
      engagement: { fr: 'Fiançailles', en: 'Engagement' },
      familyPortrait: { fr: 'Portrait de famille', en: 'Family Portrait' },
      eventCoverage: { fr: 'Couverture événement', en: 'Event Coverage' },
      weddingFilm: { fr: 'Film de mariage', en: 'Wedding Film' },
      commercial: { fr: 'Commercial', en: 'Commercial' },
      corporateVideo: { fr: 'Vidéo corporative', en: 'Corporate Video' },
      musicVideo: { fr: 'Clip musical', en: 'Music Video' },
      sunsetQuebec: { fr: 'Coucher de soleil sur Québec', en: 'Sunset Over Québec' },
      mountainView: { fr: 'Vue montagne', en: 'Mountain View' },
      realEstate: { fr: 'Immobilier', en: 'Real Estate' },
      nature: { fr: 'Nature', en: 'Nature' },
    },
  },

  // Booking
  booking: {
    title: {
      fr: 'Réserver une séance',
      en: 'Book a Session',
    },
    fullName: {
      fr: 'Nom complet',
      en: 'Full Name',
    },
    fullNamePlaceholder: {
      fr: 'Votre nom complet',
      en: 'Your full name',
    },
    email: {
      fr: 'Courriel',
      en: 'Email',
    },
    emailPlaceholder: {
      fr: 'votre@courriel.com',
      en: 'your@email.com',
    },
    service: {
      fr: 'Service',
      en: 'Service',
    },
    selectService: {
      fr: 'Sélectionnez un service',
      en: 'Select a service',
    },
    preferredDate: {
      fr: 'Date souhaitée',
      en: 'Preferred Date',
    },
    datePlaceholder: {
      fr: 'ex. 15 janvier 2025',
      en: 'e.g., January 15, 2025',
    },
    location: {
      fr: 'Lieu',
      en: 'Location',
    },
    locationPlaceholder: {
      fr: 'Ville ou adresse',
      en: 'City or address',
    },
    budget: {
      fr: 'Budget (CAD)',
      en: 'Budget (CAD)',
    },
    budgetPlaceholder: {
      fr: 'Votre fourchette de budget',
      en: 'Your budget range',
    },
    projectNotes: {
      fr: 'Notes du projet',
      en: 'Project Notes',
    },
    projectNotesPlaceholder: {
      fr: 'Parlez-moi de votre projet, votre vision ou toute demande spéciale...',
      en: 'Tell me about your project, vision, or any special requests...',
    },
    preferredContact: {
      fr: 'Méthode de contact préférée',
      en: 'Preferred Contact Method',
    },
    socialHandle: {
      fr: 'Identifiant',
      en: 'Handle',
    },
    socialHandlePlaceholder: {
      fr: 'votre_identifiant',
      en: 'your_handle',
    },
    sendRequest: {
      fr: 'Envoyer la demande',
      en: 'Send Request',
    },
    orReachOut: {
      fr: 'Ou contactez-moi directement',
      en: 'Or reach out directly',
    },
    requestSent: {
      fr: 'Demande envoyée',
      en: 'Request Sent',
    },
    requestSentMessage: {
      fr: 'Merci pour votre demande !\nJe vous répondrai par courriel bientôt.',
      en: 'Thank you for your inquiry!\nI\'ll reply by email soon.',
    },
    quickActions: {
      fr: 'Actions rapides',
      en: 'Quick Actions',
    },
    openMail: {
      fr: 'Ouvrir Mail',
      en: 'Open Mail',
    },
    requiredFields: {
      fr: 'Champs requis',
      en: 'Required Fields',
    },
    requiredFieldsMessage: {
      fr: 'Veuillez remplir votre nom, courriel et sélectionner un service.',
      en: 'Please fill in your name, email, and select a service.',
    },
    emailNotAvailable: {
      fr: 'Courriel non disponible',
      en: 'Email Not Available',
    },
    emailNotAvailableMessage: {
      fr: 'Impossible d\'ouvrir le courriel. Veuillez contacter Theodore.beaupre@icloud.com directement.',
      en: 'Unable to open email. Please contact Theodore.beaupre@icloud.com directly.',
    },
  },

  // About
  about: {
    title: {
      fr: 'À propos',
      en: 'About',
    },
    bio: {
      fr: 'Photographe et vidéaste passionné basé au Québec, je me spécialise dans la capture de paysages urbains, d\'architecture et de moments qui racontent des histoires. Chaque projet est une opportunité de créer quelque chose de vraiment unique.',
      en: "Passionate photographer and videographer based in Québec, I specialize in capturing cityscapes, architecture, and moments that tell stories. Every project is an opportunity to create something truly unique.",
    },
    stats: {
      yearsExperience: { fr: 'Années d\'expérience', en: 'Years Experience' },
      projects: { fr: 'Projets', en: 'Projects' },
      happyClients: { fr: 'Clients satisfaits', en: 'Happy Clients' },
    },
    philosophy: {
      fr: 'Philosophie',
      en: 'Philosophy',
    },
    philosophyText: {
      fr: 'Je crois que les meilleures photos capturent non seulement ce que vous voyez, mais ce que vous ressentez. Mon approche combine l\'excellence technique avec une vision artistique pour créer des images qui résonnent.',
      en: "I believe the best photos capture not just what you see, but how you feel. My approach combines technical excellence with artistic vision to create images that resonate.",
    },
    connectTitle: {
      fr: 'Connectons-nous',
      en: "Let's Connect",
    },
    connectText: {
      fr: 'Suivez mon travail et contactez-moi pour des collaborations.',
      en: 'Follow my work and reach out for collaborations.',
    },
  },

  // Contact
  contact: {
    title: {
      fr: 'Contact',
      en: 'Contact',
    },
    subtitle: {
      fr: 'Discutons',
      en: "Let's Talk",
    },
    description: {
      fr: 'Prêt à créer quelque chose de beau ensemble ? Contactez-moi et discutons de votre projet.',
      en: "Ready to create something beautiful together? Reach out and let's discuss your project.",
    },
    email: {
      fr: 'Courriel',
      en: 'Email',
    },
    tapToEmail: {
      fr: 'Touchez pour envoyer un courriel',
      en: 'Tap to email',
    },
    copyEmail: {
      fr: 'Copier',
      en: 'Copy',
    },
    copied: {
      fr: 'Copié !',
      en: 'Copied!',
    },
    location: {
      fr: 'Lieu',
      en: 'Location',
    },
    availableFor: {
      fr: 'Disponible pour des projets au Québec et au-delà',
      en: 'Available for projects in Québec and beyond',
    },
    socialMedia: {
      fr: 'Réseaux sociaux',
      en: 'Social Media',
    },
    followInstagram: {
      fr: 'Suivez-moi sur Instagram',
      en: 'Follow me on Instagram',
    },
    followTikTok: {
      fr: 'Suivez-moi sur TikTok',
      en: 'Follow me on TikTok',
    },
    quickContact: {
      fr: 'Contact rapide',
      en: 'Quick Contact',
    },
    bookSession: {
      fr: 'Réserver une séance',
      en: 'Book a Session',
    },
    bookDescription: {
      fr: 'Prêt à réserver ? Commencez avec notre formulaire de réservation simple.',
      en: 'Ready to book? Start with our simple booking form.',
    },
    startBooking: {
      fr: 'Commencer la réservation',
      en: 'Start Booking',
    },
    responseTime: {
      fr: 'Délai de réponse',
      en: 'Response Time',
    },
    responseTimeText: {
      fr: 'Je réponds généralement dans les 24-48 heures. Pour les demandes urgentes, envoyez-moi un DM sur Instagram.',
      en: 'I typically respond within 24-48 hours. For urgent inquiries, DM me on Instagram.',
    },
  },

  // Settings
  settings: {
    title: {
      fr: 'Paramètres',
      en: 'Settings',
    },
    language: {
      fr: 'Langue',
      en: 'Language',
    },
    french: {
      fr: 'Français',
      en: 'French',
    },
    english: {
      fr: 'Anglais',
      en: 'English',
    },
    selectLanguage: {
      fr: 'Sélectionner la langue',
      en: 'Select Language',
    },
  },
} as const;

// Helper function to get translation
export function t(
  key: string,
  lang: Language
): string {
  const keys = key.split('.');
  let value: unknown = translations;

  for (const k of keys) {
    if (value && typeof value === 'object' && k in value) {
      value = (value as Record<string, unknown>)[k];
    } else {
      return key;
    }
  }

  if (value && typeof value === 'object' && lang in value) {
    return (value as Record<string, string>)[lang];
  }

  return key;
}
