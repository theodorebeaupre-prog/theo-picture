import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Platform, NativeModules } from 'react-native';
import { type Language, t as translate } from './translations';

const LANGUAGE_STORAGE_KEY = '@theo_picture_language';

// Get device language
function getDeviceLanguage(): Language {
  let deviceLang = 'fr';

  if (Platform.OS === 'ios') {
    deviceLang = NativeModules.SettingsManager?.settings?.AppleLocale?.substring(0, 2) ||
                 NativeModules.SettingsManager?.settings?.AppleLanguages?.[0]?.substring(0, 2) ||
                 'fr';
  } else if (Platform.OS === 'android') {
    deviceLang = NativeModules.I18nManager?.localeIdentifier?.substring(0, 2) || 'fr';
  }

  return deviceLang === 'en' ? 'en' : 'fr';
}

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  isLoading: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguageState] = useState<Language>('fr');
  const [isLoading, setIsLoading] = useState(true);

  // Initialize language from storage or device locale
  useEffect(() => {
    const initLanguage = async () => {
      try {
        const stored = await AsyncStorage.getItem(LANGUAGE_STORAGE_KEY);
        if (stored === 'fr' || stored === 'en') {
          setLanguageState(stored);
        } else {
          // Get device language, default to French
          const defaultLang = getDeviceLanguage();
          setLanguageState(defaultLang);
          await AsyncStorage.setItem(LANGUAGE_STORAGE_KEY, defaultLang);
        }
      } catch {
        // Default to French on error
        setLanguageState('fr');
      } finally {
        setIsLoading(false);
      }
    };

    initLanguage();
  }, []);

  const setLanguage = useCallback(async (lang: Language) => {
    setLanguageState(lang);
    try {
      await AsyncStorage.setItem(LANGUAGE_STORAGE_KEY, lang);
    } catch {
      // Silently fail
    }
  }, []);

  const t = useCallback(
    (key: string) => translate(key, language),
    [language]
  );

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, isLoading }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
